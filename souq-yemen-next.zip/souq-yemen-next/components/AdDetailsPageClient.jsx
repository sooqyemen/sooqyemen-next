'use client';

import React, { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { db, firebase } from "@/lib/firebaseClient";

function safe(v) {
  return (v ?? "").toString();
}

function formatNumber(n) {
  const num = Number(n);
  if (Number.isFinite(num)) return Math.round(num).toLocaleString("en-US");
  return safe(n);
}

export default function AdDetailsPageClient({ id, initialAd }) {
  const [ad, setAd] = useState(initialAd || null);
  const [loading, setLoading] = useState(!initialAd);
  const [notFound, setNotFound] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (!id || initialAd) return;
      setLoading(true);
      try {
        const snap = await db.collection("listings").doc(id).get();
        if (!snap.exists) {
          if (!cancelled) setNotFound(true);
        } else {
          if (!cancelled) setAd({ id: snap.id, ...snap.data() });
        }
      } catch {
        if (!cancelled) setNotFound(true);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [id, initialAd]);

  // Increment views (client-side)
  useEffect(() => {
    if (!id) return;
    // Keep it best-effort: do not block rendering
    db.collection("listings")
      .doc(id)
      .set({ views: firebase.firestore.FieldValue.increment(1) }, { merge: true })
      .catch(() => {});
  }, [id]);

  const images = useMemo(() => {
    const arr = Array.isArray(ad?.images) ? ad.images : [];
    const first = ad?.imageUrl || ad?.image || null;
    const out = [...arr];
    if (first && !out.includes(first)) out.unshift(first);
    return out.filter(Boolean);
  }, [ad]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-6 bg-gray-200 rounded" />
            <div className="h-64 bg-gray-200 rounded" />
            <div className="h-5 bg-gray-200 rounded w-1/2" />
            <div className="h-20 bg-gray-200 rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (notFound || !ad) {
    return (
      <div className="min-h-screen bg-gray-50 p-4">
        <div className="max-w-3xl mx-auto bg-white rounded-2xl shadow p-6">
          <h1 className="text-xl font-bold mb-2">الإعلان غير موجود</h1>
          <p className="text-gray-600 mb-4">قد يكون الإعلان محذوفاً أو غير متاح.</p>
          <Link className="text-blue-600 underline" href="/">
            العودة للرئيسية
          </Link>
        </div>
      </div>
    );
  }

  const phone = safe(ad.phone || ad.contactPhone);
  const wa = ad.isWhatsapp !== false;

  const currency = safe(ad.currency || "YER");
  const price = safe(ad.price);

  return (
    <div className="min-h-screen bg-gray-50 p-4">
      <div className="max-w-3xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <Link className="text-blue-600 underline" href="/">
            ← الرجوع
          </Link>
          <div className="text-sm text-gray-500">رقم الإعلان: {id}</div>
        </div>

        <div className="bg-white rounded-2xl shadow overflow-hidden">
          {images.length ? (
            <div className="w-full overflow-x-auto flex gap-2 p-2">
              {images.map((src, idx) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  key={src + idx}
                  src={src}
                  alt={ad.title || "صورة الإعلان"}
                  className="h-64 w-auto rounded-xl object-cover"
                  loading={idx === 0 ? "eager" : "lazy"}
                />
              ))}
            </div>
          ) : (
            <div className="h-64 flex items-center justify-center text-gray-500">
              لا توجد صور
            </div>
          )}

          <div className="p-5 space-y-3">
            <h1 className="text-2xl font-bold">{safe(ad.title)}</h1>

            <div className="flex flex-wrap gap-2 text-sm">
              {price && (
                <span className="px-3 py-1 rounded-full bg-green-50 text-green-700">
                  السعر: {formatNumber(price)} {currency}
                </span>
              )}
              {ad.city && (
                <span className="px-3 py-1 rounded-full bg-gray-100 text-gray-700">
                  المدينة: {safe(ad.city)}
                </span>
              )}
              {ad.category && (
                <span className="px-3 py-1 rounded-full bg-gray-100 text-gray-700">
                  القسم: {safe(ad.category)}
                </span>
              )}
              <span className="px-3 py-1 rounded-full bg-gray-100 text-gray-700">
                المشاهدات: {formatNumber(ad.views || 0)}
              </span>
            </div>

            {ad.description && (
              <div className="bg-gray-50 rounded-xl p-4">
                <h2 className="font-semibold mb-2">الوصف</h2>
                <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                  {safe(ad.description)}
                </p>
              </div>
            )}

            <div className="flex flex-col sm:flex-row gap-2">
              {phone && (
                <a
                  className="inline-flex justify-center items-center px-4 py-3 rounded-xl bg-blue-600 text-white font-semibold"
                  href={`tel:${phone}`}
                >
                  اتصال: {phone}
                </a>
              )}

              {phone && wa && (
                <a
                  className="inline-flex justify-center items-center px-4 py-3 rounded-xl bg-green-600 text-white font-semibold"
                  href={`https://wa.me/${phone.replace(/\D/g, "")}`}
                  target="_blank"
                  rel="noreferrer"
                >
                  واتساب
                </a>
              )}
            </div>

            <div className="text-xs text-gray-500">
              ملاحظة: بيانات الإعلان تُعرض كما هي من المعلن.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
