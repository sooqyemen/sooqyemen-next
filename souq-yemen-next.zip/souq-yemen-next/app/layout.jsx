import "./globals.css";
import { Cairo } from "next/font/google";

const cairo = Cairo({
  subsets: ["arabic", "latin"],
  weight: ["400", "600", "700"],
  display: "swap",
});

export const metadata = {
  title: "سوق اليمن | أكبر سوق إلكتروني للبيع والشراء في اليمن",
  description:
    "سوق اليمن - أكبر منصة إلكترونية للبيع والشراء في اليمن. تصفح آلاف الإعلانات في السيارات، العقارات، الجوالات، الوظائف، والطاقة الشمسية. أضف إعلانك مجاناً الآن!",
  metadataBase: process.env.NEXT_PUBLIC_SITE_URL
    ? new URL(process.env.NEXT_PUBLIC_SITE_URL)
    : undefined,
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
  },
};

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl" className={cairo.className}>
      <head>
        <link rel="manifest" href="/manifest.json" />
      </head>
      <body>{children}</body>
    </html>
  );
}
