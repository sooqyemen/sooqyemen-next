import AppClient from "@/components/AppClient";

export default function HomePage() {
  return <AppClient />;
}
