import AdDetailsPageClient from "@/components/AdDetailsPageClient";
import { getAdminDb } from "@/lib/firebaseAdmin";

async function getAdById(id) {
  const db = getAdminDb();
  const snap = await db.collection("listings").doc(id).get();
  if (!snap.exists) return null;
  return { id: snap.id, ...snap.data() };
}

function safeText(v, max = 140) {
  const s = (v ?? "").toString().replace(/\s+/g, " ").trim();
  return s.length > max ? s.slice(0, max - 1) + "…" : s;
}

export async function generateMetadata({ params }) {
  const id = params?.id;
  try {
    const ad = await getAdById(id);

    if (!ad) {
      return {
        title: "إعلان غير موجود | سوق اليمن",
        description: "هذا الإعلان غير متوفر أو تم حذفه.",
      };
    }

    const title = safeText(ad.title || ad.name || "تفاصيل الإعلان", 70) + " | سوق اليمن";
    const description = safeText(ad.description || ad.details || "تفاصيل الإعلان في سوق اليمن", 160);

    const image =
      Array.isArray(ad.images) && ad.images.length
        ? ad.images[0]
        : ad.imageUrl || ad.image || "/icons/icon-512.png";

    return {
      title,
      description,
      openGraph: {
        title,
        description,
        type: "article",
        images: [{ url: image }],
      },
      twitter: {
        card: "summary_large_image",
        title,
        description,
        images: [image],
      },
    };
  } catch {
    // If admin creds are not set yet, do a safe fallback so the site still builds.
    return {
      title: "سوق اليمن | تفاصيل الإعلان",
      description: "تفاصيل الإعلان في سوق اليمن.",
    };
  }
}

export default async function AdPage({ params }) {
  const id = params?.id;

  let ad = null;
  try {
    ad = await getAdById(id);
  } catch {
    ad = null;
  }

  return <AdDetailsPageClient id={id} initialAd={ad} />;
}
