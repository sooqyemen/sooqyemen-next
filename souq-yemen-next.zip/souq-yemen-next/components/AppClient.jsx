'use client';

import React, { useState, useEffect, useRef, useCallback } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import L from "leaflet";
import "leaflet.markercluster";
import "leaflet/dist/leaflet.css";
import "leaflet.markercluster/dist/MarkerCluster.css";
import "leaflet.markercluster/dist/MarkerCluster.Default.css";
import { auth, db, storage, googleProvider, firebase } from "@/lib/firebaseClient";

// Fix Leaflet default marker icons (Next.js doesn't bundle Leaflet image assets by default)
if (typeof window !== "undefined") {
  // @ts-ignore
  delete L.Icon.Default.prototype._getIconUrl;
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
    iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
    shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  });
}

const RATES = { USD_TO_YER: 1600, SAR_TO_YER: 420 };
        const YEMEN_CENTER = [15.5527, 48.5164]; 
        const DEFAULT_ZOOM = 6;
        
        // بيانات المدير
        const ADMIN_EMAIL = "mansouralbarout@gmail.com";
        const ADMIN_PHONE = "770991885";

        // Helpers
        const ADMIN_EMAILS = [ADMIN_EMAIL].map(e => String(e || '').toLowerCase());
        const isAdminEmail = (email) => !!email && ADMIN_EMAILS.includes(String(email).toLowerCase());

        const getVisitorId = () => {
            try {
                let id = localStorage.getItem('sy_visitor_id');
                if (!id) {
                    // إنشاء معرف فريد أكثر قوة
                    const timestamp = Date.now().toString(36);
                    const random = Math.random().toString(36).substring(2, 15);
                    const fingerprint = [
                        navigator.userAgent,
                        navigator.language,
                        screen.width,
                        screen.height,
                        navigator.platform
                    ].join('|');
                    
                    // إنشاء hash بسيط من بصمة المتصفح
                    let hash = 0;
                    for (let i = 0; i < fingerprint.length; i++) {
                        const char = fingerprint.charCodeAt(i);
                        hash = ((hash << 5) - hash) + char;
                        hash = hash & hash;
                    }
                    
                    id = `visitor_${timestamp}_${random}_${Math.abs(hash).toString(36)}`;
                    localStorage.setItem('sy_visitor_id', id);
                }
                return id;
            } catch (e) {
                // إذا فشل localStorage، استخدم معرف مؤقت
                return 'temp_visitor_' + Date.now().toString(36);
            }
        };

        const registerSiteVisit = async (authUser) => {
            // يسجل كل زيارة للموقع حتى لو كان الزائر غير مسجل دخول
            const visitorId = getVisitorId();
            try {
                await db.collection('site_views').add({
                    visitorId,
                    uid: authUser ? authUser.uid : null,
                    email: authUser ? (authUser.email || null) : null,
                    path: (typeof window !== 'undefined' ? (window.location.pathname + window.location.search + window.location.hash) : null),
                    referrer: (typeof document !== 'undefined' ? (document.referrer || null) : null),
                    userAgent: (typeof navigator !== 'undefined' ? (navigator.userAgent || null) : null),
                    createdAt: firebase.firestore.FieldValue.serverTimestamp()
                });
            } catch (e) {
                console.warn('site view log failed:', e);
            }
        };

        const logListingView = async (listingId, authUser) => {
            // تسجيل مشاهدة إعلان حتى للزوار (وتتكرر كل مرة)
            if (!listingId) return;
            const visitorId = getVisitorId();
            try {
                // زيادة عداد المشاهدات في الإعلان الرئيسي
                await db.collection('listings').doc(listingId).update({
                    views: firebase.firestore.FieldValue.increment(1)
                });
                
                // تسجيل المشاهدة في المجموعة الفرعية
                await db.collection('listings').doc(listingId).collection('views').add({
                    visitorId,
                    uid: authUser ? authUser.uid : null,
                    email: authUser ? (authUser.email || null) : null,
                    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                    userAgent: navigator.userAgent,
                    timestamp: Date.now()
                });
            } catch (e) {
                console.warn('listing view log failed:', e);
            }
        };

        const verifyAndFixViewCount = async (listingId) => {
            try {
                // احصل على عدد المشاهدات الحقيقي من مجموعة views الفرعية
                const viewsSnapshot = await db.collection('listings').doc(listingId)
                    .collection('views').get();
                const actualViewCount = viewsSnapshot.size;
                
                // قارن مع العدد المخزن
                const listingDoc = await db.collection('listings').doc(listingId).get();
                const storedViewCount = listingDoc.data()?.views || 0;
                
                // إذا كان هناك فرق، قم بتصحيحه
                if (actualViewCount !== storedViewCount) {
                    await db.collection('listings').doc(listingId).update({
                        views: actualViewCount
                    });
                    console.log(`تم تصحيح عداد المشاهدات للإعلان ${listingId}: ${storedViewCount} → ${actualViewCount}`);
                }
                
                return actualViewCount;
            } catch (error) {
                console.error('Error verifying view count:', error);
                return 0;
            }
        };

        const normalizeListing = (l) => {
            const images = Array.isArray(l?.images)
                ? l.images.filter(Boolean).slice(0, 5)
                : (l?.image ? [l.image] : []);
            return {
                ...l,
                images,
                views: Number(l?.views || 0),
                likes: Number(l?.likes || 0),
            };
        };

        // تهيئة Firebase
        
// Firebase is initialized in lib/firebaseClient
// استخدام الأرقام اللاتينية (الإنجليزية)
        const formatNumber = (num) => Math.round(num).toLocaleString('en-US');

        // Reverse geocoding عبر OpenStreetMap (Nominatim)
        // يُرجع اسم المنطقة/الحي/المدينة إذا كانت بياناتها موجودة في OSM
        const reverseGeocodeOSM = async (lat, lon) => {
            try {
                const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=18&addressdetails=1`;
                const res = await fetch(url, { headers: { "Accept": "application/json" } });
                if (!res.ok) throw new Error("reverse geocode failed");
                const data = await res.json();

                const addr = data?.address || {};
                const city = addr.city || addr.town || addr.village || addr.county || addr.state_district || addr.state || "";
                const road = addr.road || addr.residential || addr.pedestrian || addr.footway || addr.path || "";
                const neighbourhood = addr.neighbourhood || addr.suburb || addr.quarter || addr.hamlet || "";
                const locality = addr.locality || addr.name || "";

                let label = "";
                const parts = [road, neighbourhood, locality, city].filter(Boolean);
                if (parts.length) {
                    const uniq = [];
                    for (const p of parts) if (!uniq.length || uniq[uniq.length-1] !== p) uniq.push(p);
                    label = uniq.join(" - ");
                } else if (data?.display_name) {
                    label = String(data.display_name).split(",").slice(0, 3).join("، ").trim();
                }

                return { city, label };
            } catch (e) {
                console.warn("Reverse geocoding failed:", e);
                return { city: "", label: "" };
            }
        };


        // --- Logo ---
        const Logo = () => (
            <div className="flex items-center gap-2">
                <div className="bg-white p-1 rounded-lg shadow-sm dark:bg-gray-700">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="24" height="24" className="rounded overflow-hidden" aria-label="شعار سوق اليمن">
                        <rect width="100" height="100" fill="#1e40af"/>
                        <path d="M25 35 h50 v50 a5 5 0 0 1 -5 5 h-40 a5 5 0 0 1 -5 -5 z" fill="#fff"/>
                        <path d="M35 35 v-10 a15 15 0 0 1 30 0 v10" fill="none" stroke="#eab308" strokeWidth="6"/>
                        <rect x="30" y="40" width="40" height="12" fill="#ce1126"/>
                        <rect x="30" y="52" width="40" height="12" fill="#fff"/>
                        <rect x="30" y="64" width="40" height="12" fill="#000"/>
                        <text x="50" y="80" textAnchor="middle" fill="#1e40af" fontSize="24" fontWeight="900" fontFamily="Cairo">ي</text>
                    </svg>
                </div>
                <h1 className="text-lg font-black text-white">سوق اليمن</h1>
            </div>
        );

        // --- Icons ---
        const Icons = {
            Map: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/></svg>,
            MapPin: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>,
            Grid: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/></svg>,
            Plus: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M5 12h14"/><path d="M12 5v14"/></svg>,
            User: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
            Search: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>,
            X: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>,
            Google: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" {...p}><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.26.81-.58z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>,
            Phone: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>,
            Whatsapp: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="#25D366" {...p}><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.149-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.206-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.76.982.998-3.675-.236-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.826 9.826 0 0 1 2.9 6.994c-.004 5.45-4.437 9.88-9.885 9.88m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.333.151 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.333 11.89-11.893 0-3.18-1.24-6.162-3.495-8.411"/></svg>,
            Car: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M14 16H9m10 0h3v-3.15M5 16H2v-3.15M7 10h10M5 16v4h3v-4M19 16v4h-3v-4M7.5 7h9l1.5 5h-12z"/></svg>,
            Home: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>,
            Smartphone: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/></svg>,
            Zap: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>,
            Shirt: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M20.38 3.46 16 2a4 4 0 0 1-8 0L3.62 3.46a2 2 0 0 0-1.34 2.23l.58 3.47a1 1 0 0 0 .99.84H6v10c0 1.1.9 2 2 2h8a2 2 0 0 0 2-2V10h2.15a1 1 0 0 0 .99-.84l.58-3.47a2 2 0 0 0-1.34-2.23z"/></svg>,
            Briefcase: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/></svg>,
            Monitor: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>,
            Armchair: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M19 9V6a2 2 0 0 0-2-2H7a2 2 0 0 0-2 2v3"/><path d="M3 16a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-5a2 2 0 0 0-4 0v2H7v-2a2 2 0 0 0-4 0Z"/></svg>,
            Wrench: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>,
            Wifi: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/></svg>,
            BookOpen: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>,
            ShoppingBag: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4Z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>,
            Motorcycle: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="5" cy="15" r="3"/><circle cx="19" cy="15" r="3"/><path d="M12 19V9l-3-1"/><path d="m9 8 2-4h5l2 4"/><path d="M3 15h11v4H3z"/><path d="M13 15h8"/></svg>,
            PawPrint: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 2c.6 0 1.2.5 1.2 1.2v2.6a1.2 1.2 0 1 1-2.4 0V3.2c0-.7.6-1.2 1.2-1.2zM7 6c.6 0 1.2.5 1.2 1.2v2.6a1.2 1.2 0 1 1-2.4 0V7.2c0-.7.6-1.2 1.2-1.2zM17 6c.6 0 1.2.5 1.2 1.2v2.6a1.2 1.2 0 1 1-2.4 0V7.2c0-.7.6-1.2 1.2-1.2zM12 12c-3.3 0-6 2.7-6 6 0 2.2 1.2 4.1 3 5.2V21a3 3 0 0 0 6 0v-2.2c1.8-1.1 3-3 3-5.2 0-3.3-2.7-6-6-6z"/></svg>,
            Trash: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/></svg>,
            Edit: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>,
            Message: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>,
            Bell: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>,
            Star: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
            
            StarFilled: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
            Eye: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8S1 12 1 12z"/><circle cx="12" cy="12" r="3"/></svg>,
            LogOut: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>,
Camera: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>,
            Send: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>,
            Filter: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>,
            Hammer: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m15 12-8.5 8.5c-.83.83-2.17.83-3 0 0 0 0 0 0 0a2.12 2.12 0 0 1 0-3L12 9"/><path d="M17.64 15 22 10.64"/><path d="m20.91 11.7-1.25-1.25c-.6-.6-.93-1.4-.93-2.25V2.75A2.75 2.75 0 0 0 16 0h-2.25a2.12 2.12 0 0 0-1.5.62L2.62 10.25"/><path d="M7 5.5 18.5 17"/></svg>,
            List: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>,
            Sun: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>,
            Moon: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>,
            Shield: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>,
            Ban: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="10"/><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"/></svg>,
            CheckCircle: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>,
            AlertCircle: (p) => <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>,
        };

        const CATEGORIES = [
            { id: 'all', name: 'الكل', icon: Icons.Grid, color: '#64748b' },
            { id: 'cars', name: 'سيارات', icon: Icons.Car, color: '#3b82f6' },
            { id: 'real_estate', name: 'عقارات', icon: Icons.Home, color: '#10b981' },
            { id: 'mobiles', name: 'جوالات', icon: Icons.Smartphone, color: '#8b5cf6' },
            { id: 'solar', name: 'طاقة', icon: Icons.Zap, color: '#eab308' },
            { id: 'electronics', name: 'إلكترونيات', icon: Icons.Monitor, color: '#6366f1' },
            { id: 'furniture', name: 'أثاث', icon: Icons.Armchair, color: '#a855f7' },
            { id: 'fashion', name: 'ملابس', icon: Icons.Shirt, color: '#ec4899' },
            { id: 'motorcycles', name: 'دراجات نارية', icon: Icons.Motorcycle, color: '#f97316' },
            { id: 'internet', name: 'نت وشبكات', icon: Icons.Wifi, color: '#06b6d4' },
            { id: 'jobs', name: 'وظائف', icon: Icons.Briefcase, color: '#475569' },
            { id: 'maintenance', name: 'صيانة', icon: Icons.Wrench, color: '#f43f5e' },
            { id: 'books', name: 'كتب', icon: Icons.BookOpen, color: '#14b8a6' },
            { id: 'livestock', name: 'مواشي', icon: Icons.PawPrint, color: '#d97706' },
            { id: 'yemeni_products', name: 'منتجات يمنية', icon: Icons.ShoppingBag, color: '#16a34a' },
            { id: 'others', name: 'أخرى', icon: Icons.Grid, color: '#94a3b8' },
        ];

        const CITIES = ["صنعاء", "عدن", "تعز", "الحديدة", "إب", "المكلا", "حضرموت", "ذمار", "مأرب", "عمران", "الضالع", "حجة", "البيضاء", "المهرة", "سقطرى"];

        // إعلانات افتراضية لكل الأقسام (مديرية)
        const SAMPLE_LISTINGS = [
            // سيارات
            {
                id: 'car1',
                title: 'تويوتا كامري 2022 موديل حديث',
                price: 35000,
                currency: 'USD',
                category: 'cars',
                city: 'صنعاء',
                description: 'كامري 2022 فل كامل، لون أبيض، 20 ألف كم فقط، بحالة الوكالة',
                phone: ADMIN_PHONE,
                isWhatsapp: true,
                image: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?w=400&h=300&fit=crop',
                userId: 'admin',
                userName: 'مدير سوق اليمن',
                userEmail: ADMIN_EMAIL,
                coords: [15.3694, 44.1910],
                views: 150,
                likes: 25,
                isActive: true,
                featured: true,
                isAdmin: true
            },
            // عقارات
            {
                id: 'estate1',
                title: 'فيلا فاخرة في حي الروضة صنعاء',
                price: 250000,
                currency: 'USD',
                category: 'real_estate',
                city: 'صنعاء',
                description: 'فيلا 4 غرف نوم، 3 دور، ملحق، حديقة، جراج لسيارتين',
                phone: ADMIN_PHONE,
                isWhatsapp: true,
                image: 'https://images.unsplash.com/photo-1613977257363-707ba9348227?w=400&h=300&fit=crop',
                userId: 'admin',
                userName: 'مدير سوق اليمن',
                userEmail: ADMIN_EMAIL,
                coords: [15.3547, 44.2066],
                views: 320,
                likes: 45,
                isActive: true,
                featured: true,
                isAdmin: true
            },
            // جوالات
            {
                id: 'mobile1',
                title: 'آيفون 14 برو ماكس جديد',
                price: 1200,
                currency: 'USD',
                category: 'mobiles',
                city: 'عدن',
                description: 'آيفون 14 برو ماكس 256 جيجا، ضمان سنة، شاحن أصلي',
                phone: ADMIN_PHONE,
                isWhatsapp: true,
                image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w-400&h=300&fit=crop',
                userId: 'admin',
                userName: 'مدير سوق اليمن',
                userEmail: ADMIN_EMAIL,
                coords: [12.7855, 45.0187],
                views: 210,
                likes: 38,
                isActive: true,
                isAdmin: true
            },
            // طاقة شمسية
            {
                id: 'solar1',
                title: 'نظام طاقة شمسية 5 كيلو وات',
                price: 4500,
                currency: 'USD',
                category: 'solar',
                city: 'تعز',
                description: 'نظام متكامل مع بطاريات وبوابة شحن، ضمان 10 سنوات',
                phone: ADMIN_PHONE,
                isWhatsapp: true,
                image: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?w=400&h=300&fit=crop',
                userId: 'admin',
                userName: 'مدير سوق اليمن',
                userEmail: ADMIN_EMAIL,
                coords: [13.5795, 44.0209],
                views: 180,
                likes: 32,
                isActive: true,
                isAdmin: true
            },
            // دراجات نارية
            {
                id: 'motor1',
                title: 'دراجة نارية هوندا CBR 600',
                price: 8500,
                currency: 'USD',
                category: 'motorcycles',
                city: 'الحديدة',
                description: 'موديل 2021، 600 سي سي، لون أحمر، بحالة ممتازة',
                phone: ADMIN_PHONE,
                isWhatsapp: true,
                image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=400&h=300&fit=crop',
                userId: 'admin',
                userName: 'مدير سوق اليمن',
                userEmail: ADMIN_EMAIL,
                coords: [14.8022, 42.9511],
                views: 125,
                likes: 28,
                isActive: true,
                featured: true,
                isAdmin: true
            },
            // وظائف
            {
                id: 'job1',
                title: 'مطلوب مبرمج ويب خبرة 3 سنوات',
                price: 1000,
                currency: 'USD',
                category: 'jobs',
                city: 'صنعاء',
                description: 'شركة تقنية تبحث عن مبرمج ويب بخبرة في React و Node.js',
                phone: ADMIN_PHONE,
                isWhatsapp: true,
                image: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=400&h=300&fit=crop',
                userId: 'admin',
                userName: 'مدير سوق اليمن',
                userEmail: ADMIN_EMAIL,
                coords: [15.3694, 44.1910],
                views: 95,
                likes: 15,
                isActive: true,
                isAdmin: true
            },
            // أثاث
            {
                id: 'furniture1',
                title: 'غرفة نوم كاملة خشب زان',
                price: 1500,
                currency: 'USD',
                category: 'furniture',
                city: 'إب',
                description: 'غرفة نوم 5 قطع، خشب زان عالي الجودة، جديد',
                phone: ADMIN_PHONE,
                isWhatsapp: true,
                image: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=400&h=300&fit=crop',
                userId: 'admin',
                userName: 'مدير سوق اليمن',
                userEmail: ADMIN_EMAIL,
                coords: [13.9667, 44.1833],
                views: 110,
                likes: 20,
                isActive: true,
                isAdmin: true
            },
            // منتجات يمنية
            {
                id: 'yemeni1',
                title: 'عسل سدر يمني أصلي',
                price: 50,
                currency: 'USD',
                category: 'yemeni_products',
                city: 'حضرموت',
                description: 'عسل سدر يمني طبيعي 100%، كيلو واحد، من أفضل المناحل',
                phone: ADMIN_PHONE,
                isWhatsapp: true,
                image: 'https://images.unsplash.com/photo-1587049352851-8d4e89133924?w=400&h=300&fit=crop',
                userId: 'admin',
                userName: 'مدير سوق اليمن',
                userEmail: ADMIN_EMAIL,
                coords: [15.3547, 44.2066],
                views: 200,
                likes: 42,
                isActive: true,
                isAdmin: true
            }
        ];

        // --- Components ---

        const LocationPicker = ({ onLocationSelect }) => {
            const mapRef = useRef(null);
            const mapInstance = useRef(null);
            const markerRef = useRef(null);

            useEffect(() => {
                if (!mapRef.current) return;
                if (!mapInstance.current) {
                    mapInstance.current = L.map(mapRef.current).setView(YEMEN_CENTER, DEFAULT_ZOOM);
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '&copy; سوق اليمن'
                    }).addTo(mapInstance.current);
                    mapInstance.current.on('click', async (e) => {
                        const { lat, lng } = e.latlng;

                        const applyPoint = async (lat2, lng2) => {
                            if (markerRef.current) markerRef.current.setLatLng([lat2, lng2]);
                            else {
                                markerRef.current = L.marker([lat2, lng2], { draggable: true }).addTo(mapInstance.current);
                                markerRef.current.on('dragend', async (ev) => {
                                    const p = ev.target.getLatLng();
                                    await applyPoint(p.lat, p.lng);
                                });
                            }

                            const osmUrl = `https://www.openstreetmap.org/?mlat=${lat2}&mlon=${lng2}#map=18/${lat2}/${lng2}`;
                            const r = await reverseGeocodeOSM(lat2, lng2);

                            onLocationSelect({
                                coords: [lat2, lng2],
                                city: r.city || "",
                                locationText: r.label || "",
                                locationUrl: osmUrl
                            });
                        };

                        await applyPoint(lat, lng);
                    });
                }
                setTimeout(() => mapInstance.current && mapInstance.current.invalidateSize(), 200);
            }, []);

            return <div ref={mapRef} className="w-full h-64 rounded-xl border border-gray-300 z-10 dark:border-gray-600" aria-label="خريطة تحديد الموقع" />;
        };

        const ImageUploader = ({ onImageUpload }) => {
            const [uploading, setUploading] = useState(false);
            const [progress, setProgress] = useState(0);
            const [imagePreview, setImagePreview] = useState(null);

            const handleUpload = async (e) => {
                const file = e.target.files[0];
                if (!file) return;
                
                if (!file.type.startsWith('image/')) {
                    alert('يرجى اختيار ملف صورة فقط');
                    return;
                }
                
                // عرض الصورة مباشرة
                const reader = new FileReader();
                reader.onload = (e) => {
                    setImagePreview(e.target.result);
                };
                reader.readAsDataURL(file);
                
                // رفع الصورة إلى Firebase Storage
                setUploading(true);
                setProgress(0);
                
                try {
                    const storageRef = storage.ref();
                    const timestamp = Date.now();
                    const fileName = `listing_${timestamp}_${file.name}`;
                    const imageRef = storageRef.child(`listings/${fileName}`);
                    const uploadTask = imageRef.put(file);
                    
                    uploadTask.on('state_changed',
                        (snapshot) => {
                            const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
                            setProgress(Math.round(progress));
                        },
                        (error) => {
                            console.error('Upload failed:', error);
                            alert('فشل رفع الصورة: ' + error.message);
                            setUploading(false);
                        },
                        () => {
                            uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => {
                                setUploading(false);
                                onImageUpload(downloadURL);
                                console.log('Image uploaded:', downloadURL);
                            });
                        }
                    );
                } catch (error) {
                    console.error('Upload error:', error);
                    setUploading(false);
                    alert('حدث خطأ أثناء رفع الصورة');
                }
            };

            const removeImage = () => {
                setImagePreview(null);
                onImageUpload('');
            };

            return (
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center dark:border-gray-600">
                    {imagePreview ? (
                        <div className="relative">
                            <img src={imagePreview} alt="معاينة الصورة" loading="lazy" className="w-full h-48 object-cover rounded-lg mb-4" />
                            <button onClick={removeImage} className="absolute top-2 left-2 bg-red-500 text-white p-1 rounded-full touch-feedback" aria-label="حذف الصورة"><Icons.X size={16} /></button>
                            <p className="text-sm text-green-600 dark:text-green-400">تم تحميل الصورة بنجاح</p>
                        </div>
                    ) : (
                        <>
                            <input type="file" accept="image/*" onChange={handleUpload} className="hidden" id="imageUpload" aria-label="رفع صورة" />
                            <label htmlFor="imageUpload" className="cursor-pointer touch-feedback">
                                <div className="flex flex-col items-center gap-3">
                                    <Icons.Camera className="text-4xl text-gray-400" />
                                    <span className="text-gray-600 font-bold dark:text-gray-300">
                                        {uploading ? `جاري الرفع... ${progress}%` : 'انقر لرفع صورة'}
                                    </span>
                                    <span className="text-xs text-gray-500 dark:text-gray-400">PNG, JPG بحد أقصى 5MB</span>
                                </div>
                            </label>
                        </>
                    )}
                    {uploading && (
                        <div className="mt-4">
                            <div className="w-full bg-gray-200 rounded-full h-2.5 dark:bg-gray-700">
                                <div className="bg-blue-600 h-2.5 rounded-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
                            </div>
                        </div>
                    )}
                </div>
            );
        };



        const MultiImageUploader = ({ maxFiles = 5, onImagesUpload }) => {
            const [items, setItems] = useState([]); // { preview, url, uploading, progress }
            const [busy, setBusy] = useState(false);

            const syncUrls = (nextItems) => {
                const urls = nextItems.map(x => x.url).filter(Boolean).slice(0, maxFiles);
                onImagesUpload && onImagesUpload(urls);
            };

            const uploadOne = (file, idx) => new Promise((resolve, reject) => {
                try {
                    const storageRef = storage.ref();
                    const timestamp = Date.now();
                    const safeName = (file.name || 'image').replace(/[^a-zA-Z0-9._-]/g, '_');
                    const fileName = `listing_${timestamp}_${idx}_${safeName}`;
                    const imageRef = storageRef.child(`listings/${fileName}`);
                    const uploadTask = imageRef.put(file);

                    uploadTask.on('state_changed',
                        (snapshot) => {
                            const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
                            setItems(prev => {
                                const next = [...prev];
                                if (next[idx]) next[idx] = { ...next[idx], progress, uploading: true };
                                return next;
                            });
                        },
                        (error) => reject(error),
                        () => {
                            uploadTask.snapshot.ref.getDownloadURL().then((downloadURL) => resolve(downloadURL));
                        }
                    );
                } catch (e) {
                    reject(e);
                }
            });

            const handleSelect = async (e) => {
                const files = Array.from(e.target.files || []);
                e.target.value = '';
                if (!files.length) return;

                // limit
                const remaining = Math.max(0, maxFiles - items.length);
                const picked = files.slice(0, remaining);

                for (const f of picked) {
                    if (!f.type || !f.type.startsWith('image/')) {
                        alert('يرجى اختيار ملفات صور فقط');
                        continue;
                    }
                }

                // create previews
                const previews = picked.map(f => ({ preview: URL.createObjectURL(f), url: '', uploading: true, progress: 0, file: f }));
                const baseIdx = items.length;
                const nextItems = [...items, ...previews].slice(0, maxFiles);
                setItems(nextItems);
                setBusy(true);

                try {
                    for (let i = 0; i < previews.length; i++) {
                        const absoluteIdx = baseIdx + i;
                        const file = previews[i].file;
                        try {
                            const url = await uploadOne(file, absoluteIdx);
                            setItems(prev => {
                                const next = [...prev];
                                if (next[absoluteIdx]) next[absoluteIdx] = { ...next[absoluteIdx], url, uploading: false, progress: 100 };
                                return next;
                            });
                        } catch (error) {
                            console.error('Upload failed:', error);
                            alert('فشل رفع صورة: ' + (error?.message || ''));
                            setItems(prev => {
                                const next = [...prev];
                                if (next[absoluteIdx]) next[absoluteIdx] = { ...next[absoluteIdx], uploading: false, progress: 0 };
                                return next;
                            });
                        }
                    }
                } finally {
                    setBusy(false);
                    // sync latest urls
                    setItems(prev => {
                        syncUrls(prev);
                        return prev;
                    });
                }
            };

            const removeAt = (idx) => {
                setItems(prev => {
                    const next = prev.filter((_, i) => i !== idx);
                    syncUrls(next);
                    return next;
                });
            };

            const clearAll = () => {
                setItems([]);
                onImagesUpload && onImagesUpload([]);
            };

            return (
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center dark:border-gray-600">
                    {items.length > 0 ? (
                        <div>
                            <div className="grid grid-cols-2 gap-3">
                                {items.map((it, idx) => (
                                    <div key={idx} className="relative rounded-lg overflow-hidden border dark:border-gray-700">
                                        <img src={it.preview} alt={`صورة ${idx+1}`} loading="lazy" className="w-full h-28 object-cover" />
                                        <button onClick={() => removeAt(idx)} className="absolute top-2 right-2 bg-red-600 text-white rounded-full p-1 touch-feedback" aria-label="حذف الصورة"><Icons.X size={14} /></button>
                                        {it.uploading && (
                                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-xs font-bold">
                                                {it.progress || 0}%
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>

                            <div className="flex gap-2 mt-4 justify-center">
                                {items.length < maxFiles && (
                                    <>
                                        <input type="file" accept="image/*" multiple onChange={handleSelect} className="hidden" id="imagesUpload" aria-label="رفع صور" />
                                        <label htmlFor="imagesUpload" className="px-4 py-2 bg-blue-600 text-white rounded-lg font-bold cursor-pointer touch-feedback">
                                            <Icons.Camera size={16} className="inline mr-1" /> أضف صور ({items.length}/{maxFiles})
                                        </label>
                                    </>
                                )}
                                <button onClick={clearAll} className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg font-bold touch-feedback dark:bg-gray-700 dark:text-gray-200" type="button">
                                    مسح الكل
                                </button>
                            </div>

                            <p className="text-xs text-gray-500 mt-2 dark:text-gray-400">يمكنك رفع حتى {maxFiles} صور (الأولى ستكون الغلاف).</p>
                        </div>
                    ) : (
                        <>
                            <input type="file" accept="image/*" multiple onChange={handleSelect} className="hidden" id="imagesUpload" aria-label="رفع صور" />
                            <label htmlFor="imagesUpload" className="cursor-pointer touch-feedback">
                                <div className="flex flex-col items-center gap-3">
                                    <Icons.Camera className="text-4xl text-gray-400" />
                                    <span className="text-gray-600 font-bold dark:text-gray-300">
                                        {busy ? 'جاري الرفع...' : `انقر لرفع صور (حتى ${maxFiles})`}
                                    </span>
                                    <span className="text-xs text-gray-500 dark:text-gray-400">PNG / JPG / WebP</span>
                                </div>
                            </label>
                        </>
                    )}
                </div>
            );
        };


        const ListingCard = ({ item, currentUser, onMessage, isAdmin, onDelete, onEdit, onToggleStatus, onViewDetails, onToggleFavorite, isFavorited }) => {
            const [showBidForm, setShowBidForm] = useState(false);
            const [bidAmount, setBidAmount] = useState('');
            const [bidPhone, setBidPhone] = useState('');
            const [bidContacts, setBidContacts] = useState({});
            const [bids, setBids] = useState([]);
            const [timeLeft, setTimeLeft] = useState('');

            // حساب الوقت المتبقي للمزاد
            useEffect(() => {
                if (item.isAuction && item.auctionEnd) {
                    const updateTimer = () => {
                        const now = new Date();
                        const end = new Date(item.auctionEnd);
                        const diff = end - now;
                        
                        if (diff <= 0) {
                            setTimeLeft('انتهى المزاد');
                            return;
                        }
                        
                        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
                        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                        
                        setTimeLeft(`${days} يوم : ${hours} ساعة : ${minutes} دقيقة`);
                    };
                    
                    updateTimer();
                    const interval = setInterval(updateTimer, 60000);
                    return () => clearInterval(interval);
                }
            }, [item.isAuction, item.auctionEnd]);

            // جلب المزايدات من Firestore
            useEffect(() => {
                if (item.isAuction && item.id) {
                    const unsubscribe = db.collection('bids')
                        .where('listingId', '==', item.id)
                        .orderBy('amount', 'desc')
                        .limit(5)
                        .onSnapshot(snapshot => {
                            const bidsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                            setBids(bidsData);
                        }, error => {
                            console.error('Error fetching bids:', error);
                        });
                    
                    return () => unsubscribe();
                }
            }, [item.id, item.isAuction]);

            // جلب أرقام التواصل (للمعلن/المدير فقط) لأعلى المزايدات
            useEffect(() => {
                if (!canSeeBidderContact) {
                    setBidContacts({});
                    return;
                }
                const top = bids.slice(0, 3);
                if (!top.length) {
                    setBidContacts({});
                    return;
                }
                Promise.all(
                    top.map(b =>
                        db.collection('bid_contacts').doc(b.id).get()
                            .then(doc => doc.exists ? ({ id: b.id, ...doc.data() }) : ({ id: b.id }))
                    )
                ).then(rows => {
                    const m = {};
                    rows.forEach(r => { m[r.id] = r; });
                    setBidContacts(m);
                }).catch(err => {
                    console.error('Error fetching bid contacts:', err);
                    setBidContacts({});
                });
            }, [bids, canSeeBidderContact]);



            const canSeeBidderContact = !!(isAdmin || (currentUser && item.userId === currentUser.uid));

            const getPrices = () => {
                let base = parseFloat(item.price) || 0;
                let yer = 0;
                if (item.currency === 'USD') yer = base * RATES.USD_TO_YER;
                else if (item.currency === 'SAR') yer = base * RATES.SAR_TO_YER;
                else yer = base;
                return {
                    YER: formatNumber(yer),
                    USD: formatNumber(yer / RATES.USD_TO_YER),
                    SAR: formatNumber(yer / RATES.SAR_TO_YER)
                };
            };

            const handlePlaceBid = async () => {
                if (!currentUser) {
                    alert('يجب تسجيل الدخول للمزايدة');
                    return;
                }

                if (!bidAmount || parseFloat(bidAmount) <= 0) {
                    alert('يرجى إدخال مبلغ صحيح');
                    return;
                }

                const phoneRaw = (bidPhone || '').trim();
                const phoneDigits = phoneRaw.replace(/\D/g, '');
                if (!phoneRaw || phoneDigits.length < 7) {
                    alert('يرجى إدخال رقم واتساب/اتصال صحيح');
                    return;
                }


                const highestBid = bids[0]?.amount || item.price;
                if (parseFloat(bidAmount) <= highestBid) {
                    alert(`يجب أن يكون المبلغ أعلى من ${formatNumber(highestBid)}`);
                    return;
                }

                try {
                    const bidRef = await db.collection('bids').add({
                        listingId: item.id,
                        userId: currentUser.uid,
                        userName: currentUser.displayName || currentUser.email || 'مستخدم',
                        amount: parseFloat(bidAmount),
                        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                        userEmail: currentUser.email
                    });

                    // حفظ رقم التواصل في مجموعة منفصلة (لإظهاره فقط للمعلن/المدير)
                    await db.collection('bid_contacts').doc(bidRef.id).set({
                        bidId: bidRef.id,
                        listingId: item.id,
                        userId: currentUser.uid,
                        phone: phoneRaw,
                        phoneDigits: phoneDigits,
                        createdAt: firebase.firestore.FieldValue.serverTimestamp()
                    });

                    // تحديث أعلى سعر في الإعلان
                    await db.collection('listings').doc(item.id).update({
                        price: parseFloat(bidAmount),
                        lastBidder: currentUser.uid,
                        lastBidTime: firebase.firestore.FieldValue.serverTimestamp()
                    });

                    setBidAmount('');
                    setBidPhone('');
                    setShowBidForm(false);
                    alert('تم تقديم مزايدتك بنجاح!');
                } catch (error) {
                    console.error('Error placing bid:', error);
                    alert('حدث خطأ أثناء تقديم المزايدة: ' + error.message);
                }
            };

            const p = getPrices();

            return (
                <article className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-lg transition-all duration-300 group relative dark:bg-gray-800 dark:border-gray-700 dark:hover:shadow-gray-900">
                    <div className="h-48 relative overflow-hidden bg-gray-200 dark:bg-gray-700 cursor-pointer" role="button" tabIndex={0} onClick={() => { onViewDetails && onViewDetails(item); }} onKeyDown={(e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); onViewDetails && onViewDetails(item); } }}>
                        <img 
                            src={(item.images && item.images.length ? item.images[0] : (item.image || 'https://via.placeholder.com/400x300?text=لا+توجد+صورة'))} 
                            alt={item.title} 
                            loading="lazy"
                            className="w-full h-full object-cover group-hover:scale-110 transition duration-700"
                        />
                        <div className="absolute top-2 left-2 flex gap-2 z-10">
                            <button 
                                onClick={(e) => { e.stopPropagation(); onViewDetails && onViewDetails(item); }} 
                                className="bg-black/40 text-white p-2 rounded-full backdrop-blur-sm touch-feedback"
                                aria-label="عرض التفاصيل"
                                title="عرض التفاصيل"
                            >
                                <Icons.Eye size={16} />
                            </button>
                            <button 
                                onClick={(e) => { e.stopPropagation(); onToggleFavorite && onToggleFavorite(item.id); }} 
                                className={`p-2 rounded-full backdrop-blur-sm touch-feedback ${isFavorited ? 'bg-yellow-400 text-blue-900' : 'bg-black/40 text-white'}`}
                                aria-label="إضافة للمفضلة"
                                title="المفضلة"
                            >
                                {isFavorited ? <Icons.StarFilled size={16} /> : <Icons.Star size={16} />}
                            </button>
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black/60 backdrop-blur-sm text-white text-[10px] px-2 py-1 rounded-lg flex items-center gap-1">
                            <Icons.MapPin size={10} /> {item.locationText || item.city}
                        </div>
                        {item.featured && <div className="absolute top-2 left-2 bg-yellow-400 text-yellow-900 px-2 py-1 rounded text-xs font-bold dark:bg-yellow-500">مميز</div>}
                        {item.isAuction && (
                            <div className="absolute top-2 right-2 auction-badge">
                                <Icons.Hammer size={12} /> مزاد
                            </div>
                        )}
                        {item.isAdmin && (
                            <div className="absolute top-2 right-2 admin-badge">
                                <Icons.Shield size={12} /> إداري
                            </div>
                        )}
                    </div>
                    <div className="p-4">
                        <h2 className="font-bold text-gray-800 text-base line-clamp-1 mb-2 dark:text-gray-200">{item.title}</h2>
                        <p className="text-sm text-gray-600 line-clamp-2 mb-3 dark:text-gray-400">{item.description}</p>
                        
                        {item.isAuction && (
                            <div className="mb-3 bg-red-50 border border-red-100 p-2 rounded-lg text-center dark:bg-red-900/20 dark:border-red-800/30">
                                <span className="text-xs text-red-600 font-bold block mb-1 dark:text-red-400">
                                    {timeLeft === 'انتهى المزاد' ? 'انتهى المزاد' : 'ينتهي المزاد في:'}
                                </span>
                                <span className="text-sm font-black text-red-800 dark:text-red-300">
                                    {timeLeft}
                                </span>
                                {bids.length > 0 && (
                                    <div className="mt-2 text-xs">
                                        <span className="text-gray-600 dark:text-gray-400">أعلى مزايدة: </span>
                                        <span className="font-bold text-green-600 dark:text-green-400">
                                            {formatNumber(bids[0]?.amount || item.price)} {item.currency}
                                        </span>
                                    </div>
                                )}
                            </div>
                        )}

                        <div className="bg-blue-50 rounded-xl p-3 space-y-2 dark:bg-blue-900/20 dark:border dark:border-blue-800/30">
                            <div className="flex justify-between items-center text-blue-900 font-black text-lg border-b border-blue-200 pb-2 dark:text-blue-300 dark:border-blue-800/30">
                                <span>{formatNumber(item.price)} <span className="text-xs">{item.currency === 'USD' ? '$' : (item.currency === 'SAR' ? 'ر.س' : 'ر.ي')}</span></span>
                                {item.isAuction && (
                                    <button 
                                        onClick={() => setShowBidForm(!showBidForm)}
                                        className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded-lg hover:bg-red-200 transition dark:bg-red-900/30 dark:text-red-400"
                                    >
                                        {showBidForm ? 'إخفاء' : 'زايد الآن'}
                                    </button>
                                )}
                            </div>
                            <div className="flex justify-between text-xs text-gray-600 font-bold dark:text-gray-400">
                                <span>{p.YER} ر.ي</span>
                                <span>{p.SAR} ر.س</span>
                                <span>{p.USD} $</span>
                            </div>
                        </div>

                        {/* نموذج المزايدة */}
                        {showBidForm && item.isAuction && (
                            <div className="mt-4 p-3 bg-gray-50 rounded-xl border border-gray-200 dark:bg-gray-700 dark:border-gray-600">
                                <h4 className="font-bold text-sm mb-2 dark:text-gray-300">تقديم مزايدة جديدة</h4>
                                <div
                                    className="space-y-2 mb-3"
                                    onClick={(e) => e.stopPropagation()}
                                    onMouseDown={(e) => e.stopPropagation()}
                                    onTouchStart={(e) => e.stopPropagation()}
                                >
                                    <input
                                        type="number"
                                        value={bidAmount}
                                        onChange={(e) => setBidAmount(e.target.value)}
                                        placeholder="المبلغ"
                                        className="w-full px-2 py-1.5 text-sm border rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200"
                                    />
                                    <input
                                        type="tel"
                                        inputMode="tel"
                                        value={bidPhone}
                                        onChange={(e) => setBidPhone(e.target.value)}
                                        placeholder="رقم الجوال (واتساب/اتصال)"
                                        className="w-full px-2 py-1.5 text-sm border rounded-lg dark:bg-gray-600 dark:border-gray-500 dark:text-gray-200"
                                    />
                                    <button
                                        onClick={(e) => { e.stopPropagation(); handlePlaceBid(); }}
                                        className="w-full px-3 py-2 text-sm bg-red-600 text-white rounded-lg hover:bg-red-700 transition dark:bg-red-700 dark:hover:bg-red-800"
                                    >
                                        تأكيد
                                    </button>
                                </div>
                                {bids.length > 0 && (
                                    <div className="text-xs">
                                        <p className="font-bold mb-1 dark:text-gray-300">أعلى المزايدات:</p>
                                        <div className="space-y-1 max-h-20 overflow-y-auto">
                                            {bids.slice(0, 3).map((bid, index) => (
                                                <div key={bid.id} className="flex justify-between bg-white p-1 rounded dark:bg-gray-600">
                                                    <span className="text-gray-600 dark:text-gray-300">{bid.userName}</span>
                                                    <span className="font-bold text-green-600 dark:text-green-400">
                                                        {formatNumber(bid.amount)} {item.currency}
                                                    </span>
                                                    {canSeeBidderContact && bidContacts[bid.id]?.phone && (
                                                        <span className="flex gap-2 items-center text-[11px]">
                                                            <a
                                                                href={(() => {
                                                                    const d = String(bidContacts[bid.id].phoneDigits || '').trim();
                                                                    if (!d) return 'javascript:void(0)';
                                                                    let num = d;
                                                                    if (num.startsWith('00')) num = num.slice(2);
                                                                    if (num.startsWith('0')) num = num.slice(1);
                                                                    if (!num.startsWith('967') && num.length === 9 && num.startsWith('7')) num = '967' + num;
                                                                    return `https://wa.me/${num}`;
                                                                })()}
                                                                target="_blank"
                                                                rel="noopener noreferrer"
                                                                onClick={(e) => e.stopPropagation()}
                                                                className="px-2 py-0.5 rounded bg-green-600 text-white hover:bg-green-700 dark:bg-green-700 dark:hover:bg-green-800"
                                                            >
                                                                واتساب
                                                            </a>
                                                            <a
                                                                href={`tel:${bidContacts[bid.id].phone}`}
                                                                onClick={(e) => e.stopPropagation()}
                                                                className="px-2 py-0.5 rounded bg-blue-600 text-white hover:bg-blue-700 dark:bg-blue-700 dark:hover:bg-blue-800"
                                                            >
                                                                اتصال
                                                            </a>
                                                        </span>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}

                        <div className="flex justify-between items-center mt-3 pt-2 border-t border-gray-100 dark:border-gray-700">
                            {item.isAuction ? (
                                <button 
                                    onClick={() => setShowBidForm(!showBidForm)}
                                    className="w-full bg-red-600 text-white py-2 rounded-lg font-bold text-sm hover:bg-red-700 transition flex items-center justify-center gap-2 touch-feedback dark:bg-red-700 dark:hover:bg-red-800"
                                >
                                    <Icons.Hammer size={16} /> {showBidForm ? 'إخفاء المزايدة' : 'زايد الآن'}
                                </button>
                            ) : (
                                <div className="flex gap-2 w-full">
                                    {item.phone && <a href={`tel:${item.phone}`} className="flex-1 text-center bg-gray-100 py-2 rounded-lg text-gray-600 hover:bg-gray-200 text-sm font-bold touch-feedback dark:bg-gray-700 dark:text-gray-300 dark:hover:bg-gray-600"><Icons.Phone size={16} className="inline"/> اتصال</a>}
                                    {item.isWhatsapp && item.phone && <a href={`https://wa.me/967${item.phone.replace(/^0+/, '')}`} target="_blank" rel="noopener noreferrer" className="flex-1 text-center bg-green-100 py-2 rounded-lg text-green-700 hover:bg-green-200 text-sm font-bold touch-feedback dark:bg-green-900/30 dark:text-green-400 dark:hover:bg-green-900/50"><Icons.Whatsapp size={18} className="inline"/> واتساب</a>}
                                </div>
                            )}
                        </div>
                        
                        {/* أزرار التحكم (المالك / المدير) */}
                        {(isAdmin || (currentUser && item.userId === currentUser.uid)) && (
                            <div className="flex gap-2 mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                                <button 
                                    onClick={() => onEdit(item)}
                                    className="flex-1 bg-yellow-100 text-yellow-800 py-2 rounded-lg text-xs font-bold hover:bg-yellow-200 transition touch-feedback dark:bg-yellow-900/30 dark:text-yellow-400"
                                >
                                    <Icons.Edit size={12} className="inline mr-1"/> تعديل
                                </button>
                                <button 
                                    onClick={() => onDelete(item.id)}
                                    className="flex-1 bg-red-100 text-red-700 py-2 rounded-lg text-xs font-bold hover:bg-red-200 transition touch-feedback dark:bg-red-900/30 dark:text-red-400"
                                >
                                    <Icons.Trash size={12} className="inline mr-1"/> حذف
                                </button>
                                {isAdmin && (
                                    <button 
                                        onClick={() => onToggleStatus(item.id, !item.isActive)}
                                        className={`flex-1 py-2 rounded-lg text-xs font-bold transition touch-feedback ${
                                            item.isActive 
                                                ? 'bg-green-100 text-green-700 hover:bg-green-200 dark:bg-green-900/30 dark:text-green-400' 
                                                : 'bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-700 dark:text-gray-200'
                                        }`}
                                    >
                                        {item.isActive ? 'نشط' : 'محظور'}
                                    </button>
                                )}
                            </div>
                        )}
                        
                        <div className="flex justify-between text-xs text-gray-400 mt-2 dark:text-gray-500">
                            <span className="flex items-center gap-1"><Icons.Eye size={14} /> {item.views || 0}</span>
                            <span className="flex items-center gap-1"><Icons.Star size={14} /> {item.likes || 0}</span>
                        </div>
                    </div>
                </article>
            );
        };



        const ListingDetailsModal = ({ item, isOpen, onClose, isFavorited, onToggleFavorite, onRegisterView }) => {
            const [activeImg, setActiveImg] = useState('');

            useEffect(() => {
                if (isOpen && item && item.id) {
                    onRegisterView && onRegisterView(item.id);
                }
            }, [isOpen, item && item.id]);

            useEffect(() => {
                const imgs = (item && item.images && item.images.length) ? item.images : (item && item.image ? [item.image] : []);
                setActiveImg(imgs[0] || '');
            }, [item && item.id]);

            if (!isOpen || !item) return null;

            const images = (item.images && item.images.length) ? item.images : (item.image ? [item.image] : []);
            const priceLabel = `${formatNumber(item.price || 0)} ${item.currency || 'YER'}`;

            return (
                <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }} role="dialog" aria-modal="true">
                    <div className="modal-content dark:bg-gray-800 dark:text-gray-200 fade-in max-w-3xl" onClick={(e) => e.stopPropagation()} onMouseDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()}>
                        <div className="flex justify-between items-start gap-3 mb-4">
                            <div>
                                <h2 className="text-xl font-black">{item.title}</h2>
                                <div className="mt-1 text-sm text-gray-600 dark:text-gray-400 flex flex-wrap gap-3 items-center">
                                    <span className="flex items-center gap-1"><Icons.Eye size={14} /> {item.views || 0}</span>
                                    <span className="flex items-center gap-1"><Icons.Star size={14} /> {item.likes || 0}</span>
                                    {(item.locationText || item.city) && <span className="flex items-center gap-1"><Icons.MapPin size={14} /> {item.locationText || item.city}</span>}
                                </div>
                            </div>
                            <button onClick={onClose} className="p-2 rounded-full bg-gray-100 text-gray-700 hover:bg-gray-200 touch-feedback dark:bg-gray-700 dark:text-gray-200" aria-label="إغلاق">
                                <Icons.X size={18} />
                            </button>
                        </div>

                        <div className="flex gap-2 mb-4">
                            <div className="flex-1 bg-blue-50 border border-blue-100 rounded-xl p-3 text-center dark:bg-blue-900/20 dark:border-blue-800/30">
                                <div className="text-xs text-gray-500 dark:text-gray-400">السعر</div>
                                <div className="text-lg font-black text-blue-800 dark:text-blue-300">{priceLabel}</div>
                            </div>

                            <button
                                onClick={() => onToggleFavorite && onToggleFavorite(item.id)}
                                className={`w-44 rounded-xl font-bold touch-feedback flex items-center justify-center gap-2 ${
                                    isFavorited ? 'bg-yellow-400 text-blue-900' : 'bg-gray-100 text-gray-700 dark:bg-gray-700 dark:text-gray-200'
                                }`}
                                aria-label="المفضلة"
                            >
                                {isFavorited ? <Icons.StarFilled size={18} /> : <Icons.Star size={18} />}
                                {isFavorited ? 'في المفضلة' : 'أضف للمفضلة'}
                            </button>
                        </div>

                        {activeImg && (
                            <img src={activeImg} alt="صورة الإعلان" className="w-full h-72 object-cover rounded-xl border dark:border-gray-700 mb-3" loading="lazy" />
                        )}

                        {images.length > 1 && (
                            <div className="flex gap-2 overflow-x-auto pb-2 mb-4">
                                {images.map((src, idx) => (
                                    <button
                                        key={idx}
                                        onClick={() => setActiveImg(src)}
                                        className={`shrink-0 border rounded-lg overflow-hidden touch-feedback ${activeImg === src ? 'ring-2 ring-blue-600' : ''}`}
                                        aria-label={`صورة ${idx+1}`}
                                    >
                                        <img src={src} alt={`صورة ${idx+1}`} className="w-20 h-16 object-cover" loading="lazy" />
                                    </button>
                                ))}
                            </div>
                        )}

                        {item.description && (
                            <div className="mb-4">
                                <div className="font-bold mb-2">الوصف</div>
                                <p className="text-sm text-gray-700 whitespace-pre-line dark:text-gray-300">{item.description}</p>
                            </div>
                        )}

                        <div className="flex gap-2">
                            {item.phone && <a href={`tel:${item.phone}`} className="flex-1 bg-blue-600 text-white py-3 rounded-lg font-bold hover:bg-blue-700 text-center touch-feedback"><Icons.Phone size={18} className="inline" /> اتصال</a>}
                            {item.isWhatsapp && item.phone && <a href={`https://wa.me/${item.phone.replace(/\D/g,'')}`} target="_blank" rel="noopener noreferrer" className="flex-1 bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 text-center touch-feedback"><Icons.Whatsapp size={18} className="inline" /> واتساب</a>}
                        </div>
                    </div>
                </div>
            );
        };


        const MainMap = ({ items }) => {
            const mapRef = useRef(null);
            const mapInstance = useRef(null);
            const markers = useRef(null);

            useEffect(() => {
                if (!mapRef.current) return;
                
                if (!mapInstance.current) {
                    mapInstance.current = L.map(mapRef.current).setView(YEMEN_CENTER, 6);
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: 'سوق اليمن'
                    }).addTo(mapInstance.current);
                    markers.current = L.markerClusterGroup();
                    mapInstance.current.addLayer(markers.current);
                }

                const map = mapInstance.current;
                
                // التأكد من وجود markers قبل محاولة مسحها
                if (markers.current) {
                    markers.current.clearLayers();
                    
                    if (items && items.length > 0) {
                        items.forEach(item => {
                            if (item.coords && Array.isArray(item.coords)) {
                                const m = L.marker(item.coords);
                                m.bindPopup(`<b>${item.title}</b><br>${formatNumber(item.price)} ${item.currency}<br>${(item.locationText || item.city || '')}`);
                                markers.current.addLayer(m);
                            }
                        });
                    }
                }

                // إصلاح مشكلة عدم ظهور الخريطة عند التبديل
                setTimeout(() => {
                    map.invalidateSize();
                }, 200);

            }, [items]);

            return <div ref={mapRef} className="w-full h-full" aria-label="خريطة الإعلانات" />;
        };

        const ChatSystem = ({ currentUser, listing, onClose }) => {
            const [messages, setMessages] = useState([]);
            const [newMessage, setNewMessage] = useState('');
            const [loading, setLoading] = useState(true);
            const chatId = useRef(null);
            
            useEffect(() => {
                if (!currentUser || !listing) return;

                // إنشاء معرف فريد للمحادثة
                const participants = [currentUser.uid, listing.userId].sort();
                chatId.current = `chat_${participants.join('_')}_${listing.id}`;

                // الاشتراك في المحادثة
                const unsubscribe = db.collection('chats')
                    .doc(chatId.current)
                    .collection('messages')
                    .orderBy('timestamp', 'asc')
                    .onSnapshot(snapshot => {
                        const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                        setMessages(msgs);
                        setLoading(false);
                    }, error => {
                        console.error('Error fetching messages:', error);
                        setLoading(false);
                    });

                return () => unsubscribe();
            }, [currentUser, listing]);

            const sendMessage = async () => {
                if (!newMessage.trim() || !currentUser || !listing) return;
                
                try {
                    const messageData = {
                        text: newMessage,
                        senderId: currentUser.uid,
                        senderName: currentUser.displayName || currentUser.email,
                        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                        read: false
                    };

                    // تحديث أو إنشاء محادثة
                    await db.collection('chats').doc(chatId.current).set({
                        participants: [currentUser.uid, listing.userId],
                        listingId: listing.id,
                        listingTitle: listing.title,
                        lastMessage: newMessage,
                        lastMessageTime: firebase.firestore.FieldValue.serverTimestamp(),
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                    }, { merge: true });

                    // إضافة الرسالة
                    await db.collection('chats').doc(chatId.current).collection('messages').add(messageData);

                    setNewMessage('');
                } catch (error) {
                    console.error('Error sending message:', error);
                    alert('حدث خطأ في إرسال الرسالة: ' + error.message);
                }
            };

            return (
                <div className="fixed inset-0 bg-black/50 z-[1001] flex items-center justify-center p-4" role="dialog" aria-modal="true">
                    <div className="bg-white rounded-xl w-full max-w-md h-[80vh] flex flex-col dark:bg-gray-800">
                        <div className="p-4 border-b flex justify-between items-center dark:border-gray-700">
                            <div>
                                <h3 className="font-bold dark:text-gray-200">{listing.title}</h3>
                                <p className="text-xs text-gray-500 dark:text-gray-400">محادثة مع البائع</p>
                            </div>
                            <button onClick={onClose} aria-label="إغلاق المحادثة" className="dark:text-gray-300"><Icons.X size={24}/></button>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto p-4 space-y-4">
                            {loading ? (
                                <div className="text-center py-8 dark:text-gray-400">جاري تحميل المحادثة...</div>
                            ) : messages.length === 0 ? (
                                <div className="text-center py-8 dark:text-gray-400">
                                    <p>ابدأ محادثة جديدة</p>
                                    <p className="text-sm text-gray-500 mt-2">اسأل عن تفاصيل الإعلان</p>
                                </div>
                            ) : (
                                messages.map(msg => (
                                    <div 
                                        key={msg.id} 
                                        className={`max-w-[80%] p-3 rounded-2xl ${msg.senderId === currentUser.uid ? 'mr-auto bg-blue-100 text-blue-900 dark:bg-blue-900/30 dark:text-blue-200' : 'ml-auto bg-gray-100 dark:bg-gray-700 dark:text-gray-300'}`}
                                    >
                                        <p className="text-sm">{msg.text}</p>
                                        <p className="text-xs text-gray-500 mt-1 text-left">
                                            {msg.timestamp?.toDate ? new Date(msg.timestamp.toDate()).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : 'الآن'}
                                        </p>
                                    </div>
                                ))
                            )}
                        </div>
                        
                        <div className="p-4 border-t flex gap-2 dark:border-gray-700">
                            <input 
                                value={newMessage} 
                                onChange={(e) => setNewMessage(e.target.value)}
                                onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                                placeholder="اكتب رسالتك..." 
                                className="flex-1 border rounded-lg p-3 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 dark:placeholder-gray-500" 
                                aria-label="رسالة جديدة" 
                            />
                            <button 
                                onClick={sendMessage} 
                                disabled={!newMessage.trim()}
                                className="bg-blue-600 text-white px-4 rounded-lg touch-feedback disabled:opacity-50 dark:bg-blue-700 dark:hover:bg-blue-800"
                                aria-label="إرسال الرسالة"
                            >
                                <Icons.Send size={20}/>
                            </button>
                        </div>
                    </div>
                </div>
            );
        };

        const AdminPanel = ({ user, listings, onDeleteListing, onEditListing, onToggleListingStatus }) => {
            const [showPanel, setShowPanel] = useState(false);
            const [activeTab, setActiveTab] = useState('listings');
            const [users, setUsers] = useState([]);
            const [reportedItems, setReportedItems] = useState([]);
            const [viewStats, setViewStats] = useState({});
            
            const isAdmin = !!(user && isAdminEmail(user.email));

            useEffect(() => {
                if (isAdmin && showPanel) {
                    // جلب المستخدمين
                    db.collection('users').get().then(snapshot => {
                        const usersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                        setUsers(usersData);
                    });
                    
                    // جلب الإعلانات المبلغ عنها
                    db.collection('reports').get().then(snapshot => {
                        const reportsData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                        setReportedItems(reportsData);
                    });
                }
            }, [isAdmin, showPanel]);

            const handleBanUser = async (userId) => {
                if (window.confirm('هل أنت متأكد من حظر هذا المستخدم؟')) {
                    try {
                        await db.collection('users').doc(userId).update({ banned: true });
                        alert('تم حظر المستخدم بنجاح');
                    } catch (error) {
                        alert('حدث خطأ أثناء الحظر: ' + error.message);
                    }
                }
            };

            const handleUnbanUser = async (userId) => {
                try {
                    await db.collection('users').doc(userId).update({ banned: false });
                    alert('تم إلغاء حظر المستخدم بنجاح');
                } catch (error) {
                    alert('حدث خطأ أثناء إلغاء الحظر: ' + error.message);
                }
            };

            const handleResolveReport = async (reportId) => {
                try {
                    await db.collection('reports').doc(reportId).update({ resolved: true });
                    alert('تم التعامل مع البلاغ');
                } catch (error) {
                    alert('حدث خطأ أثناء معالجة البلاغ: ' + error.message);
                }
            };

            const testViewCounter = async (listingId) => {
                if (!listingId) return;
                
                try {
                    // اختبار تسجيل مشاهدة
                    await logListingView(listingId, user);
                    
                    // احصل على إحصائيات المشاهدات
                    const viewsSnapshot = await db.collection('listings').doc(listingId)
                        .collection('views').get();
                    
                    const uniqueVisitors = new Set();
                    viewsSnapshot.docs.forEach(doc => {
                        uniqueVisitors.add(doc.data().visitorId);
                    });
                    
                    setViewStats({
                        totalViews: viewsSnapshot.size,
                        uniqueVisitors: uniqueVisitors.size,
                        lastUpdated: new Date().toLocaleString()
                    });
                    
                    alert(`تم اختبار عداد المشاهدات
إجمالي المشاهدات: ${viewsSnapshot.size}
زوار فريدون: ${uniqueVisitors.size}`);
                } catch (error) {
                    console.error('Test failed:', error);
                    alert('فشل الاختبار: ' + error.message);
                }
            };

            if (!isAdmin) return null;

            return (
                <>
                    <button 
                        onClick={() => setShowPanel(!showPanel)}
                        className="fixed bottom-20 left-4 bg-red-600 text-white p-3 rounded-full shadow-lg z-50 touch-feedback"
                        aria-label="لوحة التحكم الإدارية"
                        title="لوحة التحكم"
                    >
                        <Icons.Shield size={24} />
                    </button>
                    
                    {showPanel && (
                        <div className="fixed inset-0 bg-black/50 z-[1002] flex items-center justify-center p-4" role="dialog" aria-modal="true">
                            <div className="bg-white rounded-xl w-full max-w-4xl h-[80vh] flex flex-col dark:bg-gray-800">
                                <div className="p-4 border-b flex justify-between items-center dark:border-gray-700">
                                    <h2 className="text-xl font-bold dark:text-gray-200">
                                        <Icons.Shield className="inline mr-2" /> لوحة تحكم المدير
                                    </h2>
                                    <button onClick={() => setShowPanel(false)} aria-label="إغلاق" className="dark:text-gray-300">
                                        <Icons.X size={24}/>
                                    </button>
                                </div>
                                
                                <div className="flex border-b dark:border-gray-700">
                                    <button 
                                        onClick={() => setActiveTab('listings')}
                                        className={`flex-1 py-3 text-center ${activeTab === 'listings' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'dark:text-gray-300'}`}
                                    >
                                        الإعلانات ({listings.length})
                                    </button>
                                    <button 
                                        onClick={() => setActiveTab('users')}
                                        className={`flex-1 py-3 text-center ${activeTab === 'users' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'dark:text-gray-300'}`}
                                    >
                                        المستخدمون ({users.length})
                                    </button>
                                    <button 
                                        onClick={() => setActiveTab('reports')}
                                        className={`flex-1 py-3 text-center ${activeTab === 'reports' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'dark:text-gray-300'}`}
                                    >
                                        البلاغات ({reportedItems.length})
                                    </button>
                                    <button 
                                        onClick={() => setActiveTab('views')}
                                        className={`flex-1 py-3 text-center ${activeTab === 'views' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' : 'dark:text-gray-300'}`}
                                    >
                                        المشاهدات
                                    </button>
                                </div>
                                
                                <div className="flex-1 overflow-y-auto p-4">
                                    {activeTab === 'listings' && (
                                        <div className="space-y-3">
                                            <h3 className="font-bold mb-3 dark:text-gray-300">إدارة الإعلانات</h3>
                                            {listings.map(listing => (
                                                <div key={listing.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg dark:bg-gray-700">
                                                    <div>
                                                        <h4 className="font-bold dark:text-gray-300">{listing.title}</h4>
                                                        <p className="text-sm text-gray-600 dark:text-gray-400">
                                                            {listing.category} • {listing.city} • {formatNumber(listing.price)} {listing.currency}
                                                        </p>
                                                        <div className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                                                            <span className="inline-flex items-center gap-1"><Icons.Eye size={12} /> {listing.views || 0} مشاهدة</span>
                                                            <span className="mx-2">•</span>
                                                            <span className="inline-flex items-center gap-1"><Icons.Star size={12} /> {listing.likes || 0} إعجاب</span>
                                                        </div>
                                                    </div>
                                                    <div className="flex gap-2">
                                                        <button 
                                                            onClick={() => testViewCounter(listing.id)}
                                                            className="px-3 py-1 bg-purple-100 text-purple-700 rounded text-sm dark:bg-purple-900/30 dark:text-purple-400"
                                                        >
                                                            اختبار المشاهدات
                                                        </button>
                                                        <button 
                                                            onClick={() => onEditListing(listing)}
                                                            className="px-3 py-1 bg-yellow-100 text-yellow-800 rounded text-sm dark:bg-yellow-900/30 dark:text-yellow-400"
                                                        >
                                                            تعديل
                                                        </button>
                                                        <button 
                                                            onClick={() => onDeleteListing(listing.id)}
                                                            className="px-3 py-1 bg-red-100 text-red-700 rounded text-sm dark:bg-red-900/30 dark:text-red-400"
                                                        >
                                                            حذف
                                                        </button>
                                                        <button 
                                                            onClick={() => onToggleListingStatus(listing.id, !listing.isActive)}
                                                            className={`px-3 py-1 rounded text-sm ${listing.isActive ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-gray-100 text-gray-700 dark:bg-gray-600 dark:text-gray-300'}`}
                                                        >
                                                            {listing.isActive ? 'نشط' : 'محظور'}
                                                        </button>
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                    
                                    {activeTab === 'users' && (
                                        <div className="space-y-3">
                                            <h3 className="font-bold mb-3 dark:text-gray-300">إدارة المستخدمين</h3>
                                            {users.map(user => (
                                                <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg dark:bg-gray-700">
                                                    <div>
                                                        <h4 className="font-bold dark:text-gray-300">{user.displayName || 'مستخدم'}</h4>
                                                        <p className="text-sm text-gray-600 dark:text-gray-400">{user.email}</p>
                                                        <p className="text-xs text-gray-500 dark:text-gray-500">
                                                            {user.banned ? <span className="text-red-600 dark:text-red-400">محظور</span> : <span className="text-green-600 dark:text-green-400">نشط</span>}
                                                        </p>
                                                    </div>
                                                    <div className="flex gap-2">
                                                        {user.banned ? (
                                                            <button 
                                                                onClick={() => handleUnbanUser(user.id)}
                                                                className="px-3 py-1 bg-green-100 text-green-700 rounded text-sm dark:bg-green-900/30 dark:text-green-400"
                                                            >
                                                                إلغاء الحظر
                                                            </button>
                                                        ) : (
                                                            <button 
                                                                onClick={() => handleBanUser(user.id)}
                                                                className="px-3 py-1 bg-red-100 text-red-700 rounded text-sm dark:bg-red-900/30 dark:text-red-400"
                                                            >
                                                                حظر
                                                            </button>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                    
                                    {activeTab === 'reports' && (
                                        <div className="space-y-3">
                                            <h3 className="font-bold mb-3 dark:text-gray-300">البلاغات</h3>
                                            {reportedItems.map(report => (
                                                <div key={report.id} className="p-3 bg-gray-50 rounded-lg dark:bg-gray-700">
                                                    <div className="flex justify-between mb-2">
                                                        <h4 className="font-bold dark:text-gray-300">{report.reason}</h4>
                                                        <span className={`text-xs px-2 py-1 rounded ${report.resolved ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400'}`}>
                                                            {report.resolved ? 'تم الحل' : 'قيد المراجعة'}
                                                        </span>
                                                    </div>
                                                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{report.description}</p>
                                                    <div className="flex justify-between text-xs text-gray-500 dark:text-gray-500">
                                                        <span>المبلغ: {report.reporterName}</span>
                                                        <span>{new Date(report.timestamp?.toDate?.() || report.timestamp).toLocaleString('ar-EG')}</span>
                                                    </div>
                                                    {!report.resolved && (
                                                        <button 
                                                            onClick={() => handleResolveReport(report.id)}
                                                            className="mt-2 px-3 py-1 bg-blue-100 text-blue-700 rounded text-sm dark:bg-blue-900/30 dark:text-blue-400"
                                                        >
                                                            تم التعامل مع البلاغ
                                                        </button>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                    
                                    {activeTab === 'views' && (
                                        <div className="space-y-3">
                                            <h3 className="font-bold mb-3 dark:text-gray-300">إحصائيات المشاهدات</h3>
                                            <div className="view-stats">
                                                <div className="view-stats-grid">
                                                    <div className="view-stat-item">
                                                        <div className="view-stat-value">{viewStats.totalViews || 0}</div>
                                                        <div className="view-stat-label">إجمالي المشاهدات</div>
                                                    </div>
                                                    <div className="view-stat-item">
                                                        <div className="view-stat-value">{viewStats.uniqueVisitors || 0}</div>
                                                        <div className="view-stat-label">زوار فريدون</div>
                                                    </div>
                                                    <div className="view-stat-item">
                                                        <div className="view-stat-value">{listings.reduce((acc, curr) => acc + (curr.views || 0), 0)}</div>
                                                        <div className="view-stat-label">مشاهدات كل الإعلانات</div>
                                                    </div>
                                                </div>
                                                <p className="text-xs text-center mt-2 opacity-75">آخر تحديث: {viewStats.lastUpdated || 'لم يتم التحديث'}</p>
                                            </div>
                                            
                                            <div className="bg-gray-50 p-3 rounded-lg dark:bg-gray-700">
                                                <h4 className="font-bold mb-2 dark:text-gray-300">اختبار عداد المشاهدات</h4>
                                                <p className="text-sm text-gray-600 mb-3 dark:text-gray-400">اختر إعلاناً لاختبار نظام تسجيل المشاهدات:</p>
                                                <div className="grid grid-cols-2 gap-2">
                                                    {listings.slice(0, 4).map(listing => (
                                                        <button 
                                                            key={listing.id}
                                                            onClick={() => testViewCounter(listing.id)}
                                                            className="px-3 py-2 bg-blue-100 text-blue-700 rounded text-sm hover:bg-blue-200 dark:bg-blue-900/30 dark:text-blue-400"
                                                        >
                                                            {listing.title.substring(0, 30)}...
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                                
                                <div className="p-4 border-t text-center text-sm text-gray-500 dark:border-gray-700 dark:text-gray-400">
                                    <p>رقم التواصل الإداري: <strong>{ADMIN_PHONE}</strong></p>
                                    <p>البريد الإلكتروني: <strong>{ADMIN_EMAIL}</strong></p>
                                </div>
                            </div>
                        </div>
                    )}
                </>
            );
        };

        const UserListingsPage = ({ user, onEditAd, onDeleteAd }) => {
            const [myAds, setMyAds] = useState([]);
            const [editingAd, setEditingAd] = useState(null);
            const [editForm, setEditForm] = useState(null);
            const [loading, setLoading] = useState(true);

            // جلب إعلانات المستخدم من Firebase
            useEffect(() => {
                if (user) {
                    setLoading(true);
                    const unsubscribe = db.collection('listings')
                        .where('userId', '==', user.uid)
                        .orderBy('createdAt', 'desc')
                        .onSnapshot(snapshot => {
                            const ads = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                            setMyAds(ads);
                            setLoading(false);
                        }, error => {
                            console.error('Error fetching user ads:', error);
                            setLoading(false);
                        });
                    
                    return () => unsubscribe();
                } else {
                    setMyAds([]);
                    setLoading(false);
                }
            }, [user]);

            const handleDelete = async (adId) => {
                if (window.confirm('هل أنت متأكد من حذف هذا الإعلان؟')) {
                    try {
                        await db.collection('listings').doc(adId).delete();
                        alert('تم حذف الإعلان بنجاح');
                    } catch (error) {
                        alert('حدث خطأ أثناء الحذف: ' + error.message);
                    }
                }
            };

            const handleEdit = (ad) => {
                setEditingAd(ad);
                setEditForm({
                    title: ad.title || '',
                    price: ad.price || '',
                    currency: ad.currency || 'YER',
                    description: ad.description || '',
                    category: ad.category || 'cars',
                    city: ad.city || '',
                    phone: ad.phone || '',
                    isWhatsapp: ad.isWhatsapp || true,
                    image: ad.image || ''
                });
            };

            const saveEdit = async () => {
                if (!editForm.title || !editForm.price) {
                    alert('يرجى تعبئة الحقول المطلوبة');
                    return;
                }

                try {
                    await db.collection('listings').doc(editingAd.id).update({
                        ...editForm,
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                    });
                    setEditingAd(null);
                    alert('تم تحديث الإعلان بنجاح');
                } catch (error) {
                    alert('حدث خطأ أثناء التحديث: ' + error.message);
                }
            };

            return (
                <div className="container mx-auto px-4 py-6">
                    <h2 className="text-2xl font-bold mb-6 dark:text-gray-200">إعلاناتي ({myAds.length})</h2>
                    
                    {editingAd ? (
                        <div className="bg-white rounded-xl shadow p-4 mb-6 dark:bg-gray-800 fade-in">
                            <h3 className="font-bold mb-4 dark:text-gray-200">تعديل الإعلان</h3>
                            <div className="space-y-3">
                                <input 
                                    value={editForm.title}
                                    onChange={e => setEditForm({...editForm, title: e.target.value})}
                                    className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                                    placeholder="عنوان الإعلان"
                                />
                                <div className="grid grid-cols-2 gap-3">
                                    <input 
                                        value={editForm.price}
                                        onChange={e => setEditForm({...editForm, price: e.target.value})}
                                        className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                                        placeholder="السعر"
                                        type="number"
                                    />
                                    <select 
                                        value={editForm.currency}
                                        onChange={e => setEditForm({...editForm, currency: e.target.value})}
                                        className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                                    >
                                        <option value="YER">ريال يمني</option>
                                        <option value="SAR">ريال سعودي</option>
                                        <option value="USD">دولار</option>
                                    </select>
                                </div>
                                <select 
                                    value={editForm.category}
                                    onChange={e => setEditForm({...editForm, category: e.target.value})}
                                    className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                                >
                                    {CATEGORIES.filter(c => c.id !== 'all').map(c => (
                                        <option key={c.id} value={c.id}>{c.name}</option>
                                    ))}
                                </select>
                                <select 
                                    value={editForm.city}
                                    onChange={e => setEditForm({...editForm, city: e.target.value})}
                                    className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                                >
                                    <option value="">اختر المدينة</option>
                                    {CITIES.map(c => (
                                        <option key={c} value={c}>{c}</option>
                                    ))}
                                </select>
                                <textarea 
                                    value={editForm.description}
                                    onChange={e => setEditForm({...editForm, description: e.target.value})}
                                    className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                                    placeholder="وصف الإعلان"
                                    rows="3"
                                />
                                <div className="grid grid-cols-2 gap-3">
                                    <input 
                                        value={editForm.phone}
                                        onChange={e => setEditForm({...editForm, phone: e.target.value})}
                                        className="w-full p-3 border rounded-lg dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
                                        placeholder="رقم الهاتف"
                                    />
                                    <label className="flex items-center gap-2 cursor-pointer p-3 border rounded-lg dark:border-gray-600">
                                        <input 
                                            type="checkbox" 
                                            checked={editForm.isWhatsapp}
                                            onChange={e => setEditForm({...editForm, isWhatsapp: e.target.checked})}
                                        />
                                        <span className="text-sm font-bold dark:text-gray-300">
                                            <Icons.Whatsapp size={16} className="inline mr-1"/> واتساب
                                        </span>
                                    </label>
                                </div>
                                <div className="flex gap-2 mt-4">
                                    <button 
                                        onClick={saveEdit} 
                                        className="flex-1 bg-green-600 text-white py-3 rounded-lg font-bold hover:bg-green-700 transition"
                                    >
                                        حفظ التعديلات
                                    </button>
                                    <button 
                                        onClick={() => setEditingAd(null)} 
                                        className="flex-1 bg-gray-300 py-3 rounded-lg font-bold hover:bg-gray-400 transition dark:bg-gray-700 dark:text-gray-300"
                                    >
                                        إلغاء
                                    </button>
                                </div>
                            </div>
                        </div>
                    ) : null}

                    {loading ? (
                        <div className="text-center py-10 dark:text-gray-400">جاري تحميل إعلاناتك...</div>
                    ) : myAds.length === 0 ? (
                        <div className="text-center py-10 dark:text-gray-400">
                            <p className="text-lg mb-2">لا توجد إعلانات.</p>
                            <p className="text-sm">ابدأ بإضافة إعلانك الأول!</p>
                        </div>
                    ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {myAds.map(ad => (
                                <div key={ad.id} className="bg-white rounded-xl shadow p-4 relative dark:bg-gray-800 dark:text-gray-300 fade-in">
                                    <img 
                                        src={ad.image || 'https://via.placeholder.com/300x200?text=لا+توجد+صورة'} 
                                        alt={ad.title} 
                                        className="w-full h-40 object-cover rounded-lg mb-3"
                                    />
                                    <h3 className="font-bold mb-2 line-clamp-1">{ad.title}</h3>
                                    <p className="text-blue-600 font-bold dark:text-blue-400">
                                        {formatNumber(ad.price)} {ad.currency}
                                    </p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">
                                        {ad.city} • {CATEGORIES.find(c => c.id === ad.category)?.name || 'أخرى'}
                                    </p>
                                    <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mb-3">
                                        {ad.description}
                                    </p>
                                    <div className="flex justify-between text-xs text-gray-500 dark:text-gray-500 mb-3">
                                        <span className="flex items-center gap-1"><Icons.Eye size={12} /> {ad.views || 0} مشاهدة</span>
                                        <span className="flex items-center gap-1"><Icons.Star size={12} /> {ad.likes || 0} إعجاب</span>
                                    </div>
                                    <div className="flex gap-2 mt-4">
                                        <button 
                                            onClick={() => handleEdit(ad)} 
                                            className="flex-1 bg-yellow-100 text-yellow-800 py-2 rounded-lg text-sm font-bold hover:bg-yellow-200 transition touch-feedback dark:bg-yellow-900/30 dark:text-yellow-400"
                                        >
                                            <Icons.Edit size={14} className="inline mr-1"/> تعديل
                                        </button>
                                        <button 
                                            onClick={() => handleDelete(ad.id)} 
                                            className="flex-1 bg-red-50 text-red-700 py-2 rounded-lg text-sm font-bold hover:bg-red-100 transition touch-feedback dark:bg-red-900/30 dark:text-red-400"
                                        >
                                            <Icons.Trash size={14} className="inline mr-1"/> حذف
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            );
        };

        const NotificationSystem = ({ user }) => {
            const [show, setShow] = useState(false);
            const [notifications, setNotifications] = useState([]);
            const [unreadCount, setUnreadCount] = useState(0);

            useEffect(() => {
                if (user) {
                    const unsubscribe = db.collection('notifications')
                        .where('userId', '==', user.uid)
                        .orderBy('timestamp', 'desc')
                        .limit(10)
                        .onSnapshot(snapshot => {
                            const notifs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
                            setNotifications(notifs);
                            setUnreadCount(notifs.filter(n => !n.read).length);
                        });
                    
                    return () => unsubscribe();
                }
            }, [user]);

            const markAsRead = async (notifId) => {
                try {
                    await db.collection('notifications').doc(notifId).update({
                        read: true,
                        readAt: firebase.firestore.FieldValue.serverTimestamp()
                    });
                } catch (error) {
                    console.error('Error marking notification as read:', error);
                }
            };

            const markAllAsRead = async () => {
                try {
                    const batch = db.batch();
                    notifications.forEach(notif => {
                        if (!notif.read) {
                            const notifRef = db.collection('notifications').doc(notif.id);
                            batch.update(notifRef, {
                                read: true,
                                readAt: firebase.firestore.FieldValue.serverTimestamp()
                            });
                        }
                    });
                    await batch.commit();
                } catch (error) {
                    console.error('Error marking all as read:', error);
                }
            };

            if(!user) return null;

            return (
                <div className="relative">
                    <button 
                        onClick={() => setShow(!show)} 
                        className="relative p-2 touch-feedback" 
                        aria-label="الإشعارات"
                    >
                        <Icons.Bell size={24} className="text-white dark:text-gray-300"/>
                        {unreadCount > 0 && (
                            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
                                {unreadCount}
                            </span>
                        )}
                    </button>
                    {show && (
                        <div className="absolute left-0 top-full mt-2 w-72 bg-white rounded-xl shadow-2xl border z-50 dark:bg-gray-800 dark:border-gray-700">
                            <div className="p-3 border-b dark:border-gray-700">
                                <div className="flex justify-between items-center">
                                    <h3 className="font-bold dark:text-gray-200">الإشعارات</h3>
                                    {unreadCount > 0 && (
                                        <button 
                                            onClick={markAllAsRead}
                                            className="text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400"
                                        >
                                            تعيين الكل كمقروء
                                        </button>
                                    )}
                                </div>
                            </div>
                            <div className="max-h-80 overflow-y-auto">
                                {notifications.length === 0 ? (
                                    <div className="p-4 text-center text-gray-500 dark:text-gray-400">
                                        لا توجد إشعارات
                                    </div>
                                ) : (
                                    notifications.map(notif => (
                                        <div 
                                            key={notif.id} 
                                            className={`p-3 border-b cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 dark:border-gray-700 ${!notif.read ? 'bg-blue-50 dark:bg-blue-900/20' : ''}`}
                                            onClick={() => markAsRead(notif.id)}
                                        >
                                            <p className="text-sm dark:text-gray-300">{notif.message}</p>
                                            <p className="text-xs text-gray-500 mt-1 dark:text-gray-400">
                                                {notif.timestamp?.toDate ? new Date(notif.timestamp.toDate()).toLocaleString('ar-EG') : 'قريباً'}
                                            </p>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    )}
                    {show && <div className="fixed inset-0 z-40" onClick={() => setShow(false)}></div>}
                </div>
            );
        };

        const AddListingModal = ({ isOpen, onClose, user, onAdd }) => {
            const [formData, setFormData] = useState({
                title: '', 
                price: '', 
                currency: 'YER', 
                city: '', 
                category: 'cars', 
                phone: '', 
                isWhatsapp: true, 
                description: '', 
                coords: null, 
                image: '',
                images: [],
                isAuction: false, 
                auctionStart: '', 
                auctionEnd: ''
            });
            const [isSubmitting, setIsSubmitting] = useState(false);
            const [locating, setLocating] = useState(false);

            const autoDetectCity = () => {
                setLocating(true);

                if (!navigator.geolocation) {
                    alert("المتصفح لا يدعم تحديد الموقع");
                    setLocating(false);
                    return;
                }

                navigator.geolocation.getCurrentPosition(
                    async (pos) => {
                        const lat = pos.coords.latitude;
                        const lon = pos.coords.longitude;

                        // رابط مباشر لموقعك (OSM)
                        const osmUrl = `https://www.openstreetmap.org/?mlat=${lat}&mlon=${lon}#map=18/${lat}/${lon}`;

                        let detectedCity = "";
                        let detectedLabel = "";

                        try {
                            // Reverse Geocoding عبر Nominatim (OpenStreetMap)
                            const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&zoom=18&addressdetails=1`;
                            let data = null;

                            try {
                                const res = await fetch(url, {
                                    headers: {
                                        "Accept": "application/json",
                                        "Accept-Language": "ar"
                                    }
                                });
                                if (res.ok) data = await res.json();
                            } catch (_) {
                                // تجاهل
                            }

                            // Fallback خفيف (يعتمد على بيانات OSM أيضاً) إذا فشل Nominatim أو حجب
                            if (!data) {
                                const fallbackUrl = `https://geocode.maps.co/reverse?lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lon)}&format=json`;
                                const res2 = await fetch(fallbackUrl, { headers: { "Accept": "application/json" } });
                                if (res2.ok) data = await res2.json();
                            }

                            const addr = data?.address || {};

                            detectedCity =
                                addr.city ||
                                addr.town ||
                                addr.village ||
                                addr.municipality ||
                                addr.county ||
                                addr.state ||
                                "";

                            const road = addr.road || addr.residential || addr.street || "";
                            const neighbourhood = addr.neighbourhood || addr.suburb || addr.quarter || addr.hamlet || "";
                            const locality = addr.locality || addr.name || "";

                            const parts = [road, neighbourhood, locality, detectedCity].filter(Boolean);

                            if (parts.length) {
                                detectedLabel = parts.filter((v, i, arr) => i === 0 || v !== arr[i - 1]).join(" - ");
                            } else if (data?.display_name) {
                                detectedLabel = String(data.display_name).split(",").slice(0, 3).join("، ").trim();
                            }
                        } catch (e) {
                            console.warn("Reverse geocoding failed:", e);
                        }

                        // لو ما قدر يجيب اسم واضح، على الأقل لا نستخدم "صنعاء" كقيمة افتراضية
                        const safeCity = detectedCity || "";
                        const safeLabel = detectedLabel || safeCity || "";

                        // الحفاظ على بقية الحقول
                        setFormData(prev => ({
                            ...prev,
                            coords: [lat, lon],
                            city: safeCity || prev.city || "",
                            locationText: safeLabel || prev.locationText || "",
                            locationUrl: osmUrl
                        }));

                        setLocating(false);

                        // رسالة لطيفة للمستخدم
                        if (safeLabel) {
                            alert(`تم تحديد موقعك: ${safeLabel}`);
                        } else {
                            alert("تم تحديد الموقع بنجاح");
                        }
                    },
                    (err) => {
                        console.error(err);
                        alert("تعذر تحديد الموقع. تأكد من تفعيل خدمة الموقع.");
                        setLocating(false);
                    },
                    {
                        enableHighAccuracy: true,
                        timeout: 10000,
                        maximumAge: 0
                    }
                );
            };


            const handleSubmit = async () => {
                if (!formData.title || !formData.price || !formData.phone) {
                    alert('الرجاء تعبئة الحقول الأساسية (العنوان، السعر، رقم الهاتف)');
                    return;
                }

                setIsSubmitting(true);
                try { 
                    await onAdd(formData); 
                    onClose();
                    // إعادة تعيين النموذج
                    setFormData({
                        title: '', price: '', currency: 'YER', city: '', category: 'cars', 
                        phone: '', isWhatsapp: true, description: '', coords: null, image: '', images: [],
                        isAuction: false, auctionStart: '', auctionEnd: ''
                    });
                } 
                catch (error) { 
                    alert('فشل النشر: ' + error.message); 
                } 
                finally { 
                    setIsSubmitting(false); 
                }
            };

            // التأكد من إغلاق المودال عند الضغط على Escape
            useEffect(() => {
                const handleEscape = (e) => {
                    if (e.key === 'Escape' && isOpen) {
                        onClose();
                    }
                };
                window.addEventListener('keydown', handleEscape);
                return () => window.removeEventListener('keydown', handleEscape);
            }, [isOpen, onClose]);

            if (!isOpen) return null;

            return (
                <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }} role="dialog" aria-modal="true">
                    <div className="modal-content dark:bg-gray-800 dark:text-gray-200 fade-in" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center mb-6 border-b pb-4 dark:border-gray-700">
                            <h2 className="text-xl font-bold">إضافة إعلان جديد</h2>
                            <button onClick={onClose} aria-label="إغلاق" className="dark:text-gray-300">
                                <Icons.X size={24} />
                            </button>
                        </div>
                        
                        <div className="space-y-4">
                            <input 
                                value={formData.title} 
                                onChange={e => setFormData(prev => ({...prev, title: e.target.value}))} 
                                placeholder="عنوان الإعلان" 
                                className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 dark:placeholder-gray-500" 
                                aria-label="عنوان الإعلان" 
                            />
                            
                            <div className="grid grid-cols-2 gap-3">
                                <input 
                                    type="number" 
                                    value={formData.price} 
                                    onChange={e => setFormData(prev => ({...prev, price: e.target.value}))} 
                                    placeholder="السعر" 
                                    className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                    aria-label="سعر الإعلان" 
                                />
                                <select 
                                    value={formData.currency} 
                                    onChange={e => setFormData(prev => ({...prev, currency: e.target.value}))} 
                                    className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                    aria-label="عملة السعر"
                                >
                                    <option value="YER">ريال يمني</option>
                                    <option value="SAR">ريال سعودي</option>
                                    <option value="USD">دولار</option>
                                </select>
                            </div>
                            
                            <div className="flex items-center gap-2 p-3 bg-red-50 rounded-xl border border-red-100 dark:bg-red-900/20 dark:border-red-800/30">
                                <input 
                                    type="checkbox" 
                                    checked={formData.isAuction} 
                                    onChange={e => setFormData(prev => ({...prev, isAuction: e.target.checked}))} 
                                    className="w-5 h-5 accent-red-600" 
                                    id="auctionCheck" 
                                />
                                <label htmlFor="auctionCheck" className="text-sm font-bold text-red-800 cursor-pointer dark:text-red-400">
                                    عرض كمزاد علني 🔥
                                </label>
                            </div>
                            
                            {formData.isAuction && (
                                <div className="grid grid-cols-2 gap-3 bg-red-50 p-3 rounded-xl dark:bg-red-900/20">
                                    <div>
                                        <label className="text-xs font-bold text-gray-500 block mb-1 dark:text-gray-400">بداية المزاد</label>
                                        <input 
                                            type="datetime-local" 
                                            value={formData.auctionStart}
                                            onChange={e => setFormData(prev => ({...prev, auctionStart: e.target.value}))}
                                            className="w-full p-2 border rounded-lg text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                            aria-label="تاريخ بداية المزاد" 
                                        />
                                    </div>
                                    <div>
                                        <label className="text-xs font-bold text-gray-500 block mb-1 dark:text-gray-400">نهاية المزاد</label>
                                        <input 
                                            type="datetime-local" 
                                            value={formData.auctionEnd}
                                            onChange={e => setFormData(prev => ({...prev, auctionEnd: e.target.value}))}
                                            className="w-full p-2 border rounded-lg text-sm dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                            aria-label="تاريخ نهاية المزاد" 
                                        />
                                    </div>
                                </div>
                            )}

                            <div className="grid grid-cols-2 gap-3">
                                <select 
                                    value={formData.category} 
                                    onChange={e => setFormData(prev => ({...prev, category: e.target.value}))} 
                                    className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                    aria-label="فئة الإعلان"
                                >
                                    {CATEGORIES.filter(c => c.id !== 'all').map(c => (
                                        <option key={c.id} value={c.id}>{c.name}</option>
                                    ))}
                                </select>
                                <select 
                                    value={formData.city} 
                                    onChange={e => setFormData(prev => ({
                                        ...prev,
                                        city: e.target.value,
                                        // إذا ما كتب المستخدم اسم موقع يدوي، خله يأخذ قيمة المدينة المختارة
                                        locationText: (prev.locationText && prev.locationText !== prev.city) ? prev.locationText : (e.target.value || prev.locationText || "")
                                    }))} 
                                    className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                    aria-label="المدينة"
                                >
                                    <option value="">اختر المدينة</option>
                                    {CITIES.map(c => (
                                        <option key={c} value={c}>{c}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="mt-3">
                                <input
                                    value={formData.locationText || ''}
                                    onChange={e => setFormData(prev => ({...prev, locationText: e.target.value}))}
                                    placeholder="اسم المنطقة / القرية / الحي (اختياري)"
                                    className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"
                                    aria-label="اسم المنطقة أو القرية أو الحي"
                                />
                            </div>

                            
                            {(formData.locationText || formData.locationUrl) && (
                                <div className="mt-2 text-sm flex items-center gap-2 text-lime-600 dark:text-lime-300">
                                    <span className="truncate">📍 {formData.locationText || 'تم تحديد موقعك على الخريطة'}</span>
                                    {formData.locationUrl && (
                                        <a 
                                            href={formData.locationUrl} 
                                            target="_blank" 
                                            rel="noopener noreferrer"
                                            className="underline whitespace-nowrap"
                                        >
                                            فتح
                                        </a>
                                    )}
                                </div>
                            )}

                            <button
                                onClick={autoDetectCity} 
                                disabled={locating}
                                className="w-full bg-green-50 text-green-700 p-3 rounded-lg text-sm font-bold hover:bg-green-100 transition disabled:opacity-50 dark:bg-green-900/20 dark:text-green-400 dark:hover:bg-green-900/30"
                            >
                                {locating ? 'جاري تحديد الموقع...' : '📍 تحديد مدينتي وموقعي تلقائياً'}
                            </button>
                            
                            <div className="grid grid-cols-2 gap-3 items-center">
                                <input 
                                    type="tel" 
                                    value={formData.phone} 
                                    onChange={e => setFormData(prev => ({...prev, phone: e.target.value}))} 
                                    placeholder="رقم الجوال" 
                                    className="w-full p-3 border rounded-xl dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                    aria-label="رقم الجوال" 
                                />
                                <label className="flex items-center gap-2 cursor-pointer p-3 border rounded-xl dark:border-gray-600">
                                    <input 
                                        type="checkbox" 
                                        checked={formData.isWhatsapp} 
                                        onChange={e => setFormData(prev => ({...prev, isWhatsapp: e.target.checked}))} 
                                    />
                                    <span className="text-sm font-bold dark:text-gray-300">
                                        <Icons.Whatsapp size={16} className="inline mr-1"/> واتساب
                                    </span>
                                </label>
                            </div>
                            
                            <textarea 
                                value={formData.description} 
                                onChange={e => setFormData(prev => ({...prev, description: e.target.value}))} 
                                placeholder="تفاصيل الإعلان..." 
                                className="w-full p-3 border rounded-xl h-24 dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200" 
                                aria-label="تفاصيل الإعلان"
                            ></textarea>
                            
                            <MultiImageUploader 
                                maxFiles={5}
                                onImagesUpload={(urls) => setFormData(prev => ({...prev, images: urls, image: (urls && urls[0]) ? urls[0] : ''}))} 
                            />
                            
                            <div className="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">
                                تحديد دقيق على الخريطة (اختياري):
                            </div>
                            <LocationPicker 
                                onLocationSelect={(loc) => setFormData(prev => ({
                                    ...prev,
                                    coords: loc?.coords || prev.coords,
                                    city: (loc?.city ?? prev.city ?? ""),
                                    locationText: (loc?.locationText || prev.locationText || ""),
                                    locationUrl: (loc?.locationUrl || prev.locationUrl || "")
                                }))} 
                            />
                            
                            <button 
                                onClick={handleSubmit} 
                                disabled={isSubmitting}
                                className="w-full bg-yellow-400 text-blue-900 font-bold py-3.5 rounded-xl hover:bg-yellow-500 transition disabled:opacity-50 touch-feedback dark:bg-yellow-500 dark:text-gray-900"
                            >
                                {isSubmitting ? 'جاري النشر...' : 'نشر الإعلان'}
                            </button>
                        </div>
                    </div>
                </div>
            );
        };

        const AuthModal = ({ isOpen, onClose, onLogin }) => {
            const [isLogin, setIsLogin] = useState(true);
            const [email, setEmail] = useState('');
            const [password, setPassword] = useState('');
            const [confirmPassword, setConfirmPassword] = useState('');
            const [name, setName] = useState('');
            const [error, setError] = useState('');
            const [loading, setLoading] = useState(false);

            // التأكد من إغلاق المودال عند الضغط على Escape
            useEffect(() => {
                const handleEscape = (e) => {
                    if (e.key === 'Escape' && isOpen) {
                        onClose();
                    }
                };
                window.addEventListener('keydown', handleEscape);
                return () => window.removeEventListener('keydown', handleEscape);
            }, [isOpen, onClose]);

            if (!isOpen) return null;

            const handleSubmit = async (e) => {
                e.preventDefault();
                setError('');
                
                if (!isLogin && password !== confirmPassword) {
                    setError('كلمات المرور غير متطابقة');
                    return;
                }
                
                if (!isLogin && !name.trim()) {
                    setError('الرجاء إدخال الاسم');
                    return;
                }

                setLoading(true);
                try {
                    if (isLogin) {
                        await auth.signInWithEmailAndPassword(email, password);
                    } else {
                        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
                        // تحديث اسم المستخدم
                        await userCredential.user.updateProfile({
                            displayName: name
                        });
                        // حفظ بيانات المستخدم في Firestore
                        await db.collection('users').doc(userCredential.user.uid).set({
                            uid: userCredential.user.uid,
                            email: userCredential.user.email,
                            displayName: name,
                            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                            isAdmin: userCredential.user.email === ADMIN_EMAIL,
                            banned: false
                        });
                    }
                    onLogin(); 
                    onClose();
                } catch (err) { 
                    console.error('Auth error:', err);
                    let errorMessage = 'حدث خطأ أثناء المصادقة';
                    switch (err.code) {
                        case 'auth/email-already-in-use':
                            errorMessage = 'البريد الإلكتروني مستخدم بالفعل';
                            break;
                        case 'auth/invalid-email':
                            errorMessage = 'البريد الإلكتروني غير صالح';
                            break;
                        case 'auth/weak-password':
                            errorMessage = 'كلمة المرور ضعيفة (يجب أن تكون 6 أحرف على الأقل)';
                            break;
                        case 'auth/user-not-found':
                            errorMessage = 'المستخدم غير موجود';
                            break;
                        case 'auth/wrong-password':
                            errorMessage = 'كلمة المرور غير صحيحة';
                            break;
                    }
                    setError(errorMessage); 
                } finally { 
                    setLoading(false); 
                }
            };

            const handleGoogle = async () => {
                try { 
                    const result = await auth.signInWithPopup(googleProvider);
                    const user = result.user;
                    
                    // حفظ بيانات المستخدم في Firestore
                    await db.collection('users').doc(user.uid).set({
                        uid: user.uid,
                        email: user.email,
                        displayName: user.displayName,
                        photoURL: user.photoURL,
                        createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                        isAdmin: user.email === ADMIN_EMAIL,
                        banned: false
                    }, { merge: true });
                    
                    onLogin(); 
                    onClose(); 
                } 
                catch (err) { 
                    console.error('Google auth error:', err);
                    setError(err.message); 
                }
            };

            return (
                <div className="modal-overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }} role="dialog" aria-modal="true">
                    <div className="modal-content dark:bg-gray-800 dark:text-gray-200 fade-in" onClick={e => e.stopPropagation()}>
                        <div className="flex justify-between items-center mb-6">
                            <h2 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
                                {isLogin ? 'تسجيل الدخول' : 'إنشاء حساب جديد'}
                            </h2>
                            <button onClick={onClose} aria-label="إغلاق" className="dark:text-gray-300">
                                <Icons.X size={24}/>
                            </button>
                        </div>
                        
                        {error && (
                            <div className="bg-red-50 text-red-600 p-3 rounded-xl mb-4 text-sm dark:bg-red-900/20 dark:text-red-400">
                                {error}
                            </div>
                        )}
                        
                        <button 
                            onClick={handleGoogle} 
                            className="w-full bg-white border border-gray-300 py-3 rounded-xl flex items-center justify-center gap-3 font-bold hover:bg-gray-50 shadow-sm transition mb-4 touch-feedback dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 dark:hover:bg-gray-600" 
                            aria-label="المتابعة باستخدام جوجل"
                        >
                            <Icons.Google size={24} /> المتابعة باستخدام Google
                        </button>
                        
                        <div className="flex items-center mb-4">
                            <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700"></div>
                            <span className="px-2 text-gray-400 text-sm dark:text-gray-500">أو</span>
                            <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700"></div>
                        </div>
                        
                        <form onSubmit={handleSubmit} className="space-y-4">
                            {!isLogin && (
                                <input 
                                    type="text" 
                                    placeholder="الاسم الكامل" 
                                    required 
                                    value={name} 
                                    onChange={e => setName(e.target.value)} 
                                    className="w-full p-3 rounded-xl border outline-none dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 dark:placeholder-gray-500" 
                                    aria-label="الاسم الكامل" 
                                />
                            )}
                            
                            <input 
                                type="email" 
                                placeholder="البريد الإلكتروني" 
                                required 
                                value={email} 
                                onChange={e => setEmail(e.target.value)} 
                                className="w-full p-3 rounded-xl border outline-none dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 dark:placeholder-gray-500" 
                                aria-label="البريد الإلكتروني" 
                            />
                            
                            <input 
                                type="password" 
                                placeholder="كلمة المرور" 
                                required 
                                value={password} 
                                onChange={e => setPassword(e.target.value)} 
                                className="w-full p-3 rounded-xl border outline-none dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 dark:placeholder-gray-500" 
                                aria-label="كلمة المرور" 
                            />
                            
                            {!isLogin && (
                                <input 
                                    type="password" 
                                    placeholder="تأكيد كلمة المرور" 
                                    required 
                                    value={confirmPassword} 
                                    onChange={e => setConfirmPassword(e.target.value)} 
                                    className="w-full p-3 rounded-xl border outline-none dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200 dark:placeholder-gray-500" 
                                    aria-label="تأكيد كلمة المرور" 
                                />
                            )}
                            
                            <button 
                                disabled={loading} 
                                className="w-full bg-blue-600 text-white font-bold py-3.5 rounded-xl hover:bg-blue-700 transition touch-feedback dark:bg-blue-700 dark:hover:bg-blue-800"
                            >
                                {loading ? '...' : (isLogin ? 'تسجيل الدخول' : 'إنشاء حساب')}
                            </button>
                        </form>
                        
                        <div className="mt-6 text-center">
                            <button 
                                onClick={() => setIsLogin(!isLogin)} 
                                className="text-blue-600 font-bold touch-feedback dark:text-blue-400"
                            >
                                {isLogin ? 'ليس لديك حساب؟ سجل الآن' : 'لديك حساب؟ سجل دخول'}
                            </button>
                        </div>
                    </div>
                </div>
            );
        };

        const ViewStatistics = ({ listings }) => {
            const [stats, setStats] = useState([]);
            const [loading, setLoading] = useState(true);

            useEffect(() => {
                const fetchStats = async () => {
                    setLoading(true);
                    const statsData = [];
                    
                    for (const listing of listings.slice(0, 10)) { // أول 10 إعلانات فقط
                        try {
                            const viewsSnapshot = await db.collection('listings').doc(listing.id)
                                .collection('views').get();
                            
                            const uniqueVisitors = new Set();
                            viewsSnapshot.docs.forEach(doc => {
                                uniqueVisitors.add(doc.data().visitorId);
                            });
                            
                            statsData.push({
                                title: listing.title,
                                id: listing.id,
                                storedViews: listing.views || 0,
                                actualViews: viewsSnapshot.size,
                                uniqueVisitors: uniqueVisitors.size,
                                discrepancy: (listing.views || 0) - viewsSnapshot.size
                            });
                        } catch (error) {
                            console.error(`Error fetching stats for ${listing.id}:`, error);
                        }
                    }
                    
                    setStats(statsData);
                    setLoading(false);
                };
                
                fetchStats();
            }, [listings]);

            if (loading) return <div className="text-center py-4">جاري تحميل الإحصائيات...</div>;

            return (
                <div className="bg-white rounded-xl shadow p-4 mt-4 dark:bg-gray-800">
                    <h3 className="text-lg font-bold mb-4 dark:text-gray-200">إحصائيات المشاهدات</h3>
                    <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead>
                                <tr className="border-b dark:border-gray-700">
                                    <th className="text-right p-2 dark:text-gray-300">الإعلان</th>
                                    <th className="text-right p-2 dark:text-gray-300">المشاهدات المخزنة</th>
                                    <th className="text-right p-2 dark:text-gray-300">المشاهدات الفعلية</th>
                                    <th className="text-right p-2 dark:text-gray-300">زوار فريدون</th>
                                    <th className="text-right p-2 dark:text-gray-300">الفرق</th>
                                </tr>
                            </thead>
                            <tbody>
                                {stats.map((item, index) => (
                                    <tr key={index} className="border-b dark:border-gray-700">
                                        <td className="p-2 dark:text-gray-300">{item.title}</td>
                                        <td className={`p-2 ${item.discrepancy > 0 ? 'text-red-600' : ''} dark:text-gray-300`}>
                                            {item.storedViews}
                                        </td>
                                        <td className="p-2 text-green-600 dark:text-green-400">
                                            {item.actualViews}
                                        </td>
                                        <td className="p-2 text-blue-600 dark:text-blue-400">
                                            {item.uniqueVisitors}
                                        </td>
                                        <td className={`p-2 ${item.discrepancy > 0 ? 'text-red-600' : 'text-green-600'} dark:text-gray-300`}>
                                            {item.discrepancy > 0 ? `+${item.discrepancy}` : item.discrepancy}
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            );
        };

        const Footer = ({ listings }) => {
            const totalViews = listings.reduce((acc, curr) => acc + (curr.views || 0), 0);
            const totalLikes = listings.reduce((acc, curr) => acc + (curr.likes || 0), 0);
            const activeAuctions = listings.filter(i => i.isAuction).length;
            const adminListings = listings.filter(i => i.isAdmin).length;

            return (
                <footer className="page-footer" role="contentinfo">
                    <div className="grid grid-cols-3 gap-4 mb-4">
                        <div className="text-center">
                            <span className="block text-2xl font-bold text-gray-800 dark:text-gray-300">
                                {listings.length}
                            </span>
                            <span className="text-xs">إعلان نشط</span>
                        </div>
                        <div className="text-center">
                            <span className="block text-2xl font-bold text-gray-800 dark:text-gray-300">
                                {formatNumber(totalViews)}
                            </span>
                            <span className="text-xs">مشاهدة</span>
                        </div>
                        <div className="text-center">
                            <span className="block text-2xl font-bold text-red-600 dark:text-red-400">
                                {activeAuctions}
                            </span>
                            <span className="text-xs">مزاد جاري</span>
                        </div>
                    </div>
                    
                    <div className="grid grid-cols-4 gap-4 mb-6">
                        <div className="text-center">
                            <span className="block text-xl font-bold text-green-600 dark:text-green-400">
                                {formatNumber(totalLikes)}
                            </span>
                            <span className="text-xs">إعجاب</span>
                        </div>
                        <div className="text-center">
                            <span className="block text-xl font-bold text-purple-600 dark:text-purple-400">
                                {new Set(listings.map(l => l.city)).size}
                            </span>
                            <span className="text-xs">مدينة</span>
                        </div>
                        <div className="text-center">
                            <span className="block text-xl font-bold text-yellow-600 dark:text-yellow-400">
                                {new Set(listings.map(l => l.userId)).size}
                            </span>
                            <span className="text-xs">بائع</span>
                        </div>
                        <div className="text-center">
                            <span className="block text-xl font-bold text-blue-600 dark:text-blue-400">
                                {adminListings}
                            </span>
                            <span className="text-xs">إعلان إداري</span>
                        </div>
                    </div>
                    
                    <div className="text-xs text-gray-400 pt-4 border-t border-gray-200 dark:border-gray-700">
                        <p className="mb-2">&copy; {new Date().getFullYear()} سوق اليمن. جميع الحقوق محفوظة.</p>
                        <p>أكبر منصة للبيع والشراء في اليمن - تواصل مباشر بين البائع والمشتري</p>
                        <p className="mt-2 text-red-400 dark:text-red-300">رقم التواصل الإداري: <strong>{ADMIN_PHONE}</strong></p>
                    </div>
                </footer>
            );
        };

        // --- Dark Mode Toggle ---
        const DarkModeToggle = () => {
            const [darkMode, setDarkMode] = useState(false);

            useEffect(() => {
                const savedMode = localStorage.getItem('darkMode') === 'true';
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                
                if (savedMode || (!savedMode && prefersDark)) {
                    setDarkMode(true);
                    document.body.classList.add('dark-mode');
                }
            }, []);

            const toggleDarkMode = () => {
                const newMode = !darkMode;
                setDarkMode(newMode);
                
                if (newMode) {
                    document.body.classList.add('dark-mode');
                } else {
                    document.body.classList.remove('dark-mode');
                }
                
                localStorage.setItem('darkMode', newMode);
            };

            return (
                <button 
                    onClick={toggleDarkMode} 
                    className="text-white header-btn rounded-full touch-feedback"
                    aria-label={darkMode ? "تفعيل الوضع الفاتح" : "تفعيل الوضع الداكن"}
                    title={darkMode ? "الوضع الفاتح" : "الوضع الداكن"}
                >
                    {darkMode ? <Icons.Sun size={18} /> : <Icons.Moon size={18} />}
                </button>
            );
        };

        // --- APP ---
        const AppClient = () => {
            const [view, setView] = useState('home');
            const [search, setSearch] = useState('');
            const [activeCat, setActiveCat] = useState('all');
            const [listings, setListings] = useState([]);
            const [filtered, setFiltered] = useState([]);
            const [user, setUser] = useState(null);
            const [modals, setModals] = useState({ auth: false, add: false });
            const [showChat, setShowChat] = useState(null);
            const [loading, setLoading] = useState(true);
            const [isAdmin, setIsAdmin] = useState(false);
            const [selectedListingId, setSelectedListingId] = useState(null);
            const [favoritesSet, setFavoritesSet] = useState(new Set());

            
            // تسجيل مشاهدة للموقع لكل فتح/زيارة (حتى الزائر بدون تسجيل دخول)
            useEffect(() => {
                registerSiteVisit(auth.currentUser || null);
            }, []);

            const registerView = async (listingId) => {
                if (!listingId) return;

                // 1) زيادة العداد (لإظهار العدد بسرعة داخل البطاقات/التفاصيل)
                try {
                    await db.collection('listings').doc(listingId).update({
                        views: firebase.firestore.FieldValue.increment(1)
                    });
                } catch (e) {
                    // قد يفشل عند الزوار إذا كانت قواعد Firestore تمنع التحديث
                    console.warn('views increment failed:', e);
                }

                // 2) سجل مشاهدة مفصلة (تعمل للزوار وللمسجلين) — وتسجل كل مرة
                await logListingView(listingId, user);
            };

useEffect(() => {
                const unsubscribeAuth = auth.onAuthStateChanged(async (authUser) => {
                    setUser(authUser);
                    if (authUser) {
                        console.log('User logged in:', authUser.email);
                        /* isAdmin computed after loading user profile */
                        
                        // التأكد من وجود بيانات المستخدم في Firestore
                        const userDoc = await db.collection('users').doc(authUser.uid).get();
                        const existingData = userDoc.exists ? (userDoc.data() || {}) : null;
                        const adminByRole = existingData && existingData.role === 'admin';
                        const adminByEmail = isAdminEmail(authUser.email);
                        setIsAdmin(!!(adminByEmail || adminByRole));

                        if (!userDoc.exists) {
                            await db.collection('users').doc(authUser.uid).set({
                                role: isAdminEmail(authUser.email) ? 'admin' : 'user',
                                uid: authUser.uid,
                                email: authUser.email,
                                displayName: authUser.displayName || authUser.email,
                                photoURL: authUser.photoURL || '',
                                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                                isAdmin: authUser.email === ADMIN_EMAIL,
                                banned: false
                            });
                        }
                    } else {
                        setIsAdmin(false);
                    }
                });
                
                const unsubscribeListings = db.collection('listings')
                    .orderBy('createdAt', 'desc')
                    .onSnapshot(snapshot => {
                        const fetched = snapshot.docs.map(doc => normalizeListing({ id: doc.id, ...doc.data() }));
                        console.log('Fetched listings:', fetched.length);
                        
                        // إذا لم تكن هناك إعلانات، أضف الإعلانات الافتراضية
                        if (fetched.length === 0 && isAdmin) {
                            addSampleListings();
                        }
                        
                        setListings(fetched);
                        setFiltered(fetched);
                        setLoading(false);
                    }, err => { 
                        console.log("Firestore fetch error:", err);
                        setLoading(false);
                    });
                
                return () => { 
                    unsubscribeAuth(); 
                    unsubscribeListings(); 
                }
            }, [isAdmin]);

            // تحميل المفضلة (للمستخدم أو للضيف)
            useEffect(() => {
                let unsubscribe = null;

                const loadGuest = () => {
                    try {
                        const raw = localStorage.getItem('sy_favorites');
                        const arr = raw ? JSON.parse(raw) : [];
                        setFavoritesSet(new Set(Array.isArray(arr) ? arr : []));
                    } catch {
                        setFavoritesSet(new Set());
                    }
                };

                if (user) {
                    unsubscribe = db.collection('users').doc(user.uid).collection('favorites')
                        .onSnapshot(snapshot => {
                            const ids = snapshot.docs.map(d => d.id);
                            setFavoritesSet(new Set(ids));
                        }, (err) => {
                            console.warn('Favorites snapshot error:', err);
                        });
                } else {
                    loadGuest();
                }

                return () => { if (unsubscribe) unsubscribe(); };
            }, [user]);

            const setGuestFavorites = (setObj) => {
                try {
                    const arr = Array.from(setObj);
                    localStorage.setItem('sy_favorites', JSON.stringify(arr));
                } catch {}
            };

            const toggleFavorite = async (listingId) => {
                if (!listingId) return;
                const next = new Set(favoritesSet);
                const isFav = next.has(listingId);

                // optimistic update
                if (isFav) next.delete(listingId); else next.add(listingId);
                setFavoritesSet(next);
                if (!user) setGuestFavorites(next);

                try {
                    // حفظ المفضلة
                    if (user) {
                        const favRef = db.collection('users').doc(user.uid).collection('favorites').doc(listingId);
                        if (isFav) await favRef.delete();
                        else await favRef.set({ createdAt: firebase.firestore.FieldValue.serverTimestamp() });
                    }

                    // تحديث العداد على الإعلان (likes)
                    await db.collection('listings').doc(listingId).update({
                        likes: firebase.firestore.FieldValue.increment(isFav ? -1 : 1)
                    });
                } catch (e) {
                    console.warn('toggleFavorite failed:', e);
                }
            };

            const handleLogout = async () => {
                try {
                    await auth.signOut();
                    setView('home');
                    setSelectedListingId(null);
                    alert('تم تسجيل الخروج بنجاح');
                } catch (e) {
                    alert('تعذر تسجيل الخروج: ' + (e?.message || ''));
                }
            };


            const addSampleListings = async () => {
                for (const listing of SAMPLE_LISTINGS) {
                    try {
                        await db.collection('listings').add({
                            ...listing,
                            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                        });
                    } catch (error) {
                        console.error('Error adding sample listing:', error);
                    }
                }
            };

            const handleAddListing = async (formData) => {
                if (!user) {
                    alert('يجب تسجيل الدخول أولاً');
                    setModals({ auth: true, add: false });
                    return;
                }

                try {
                        // دعم رفع عدة صور (حتى 5) - الأولى هي الغلاف
    const uploadedImages = Array.isArray(formData.images) ? formData.images.filter(Boolean).slice(0, 5) : [];
    const fallbackCover = formData.image || `https://source.unsplash.com/random/400x300?${formData.category}`;
    const coverImage = (uploadedImages[0] || fallbackCover);

    const newListing = {
    ...formData,
    images: uploadedImages.length ? uploadedImages : [coverImage],
    image: coverImage,
    userId: user.uid,
    userName: user.displayName || user.email,
    userEmail: user.email,
    userPhoto: user.photoURL || '',
    createdAt: firebase.firestore.FieldValue.serverTimestamp(),
    updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
    price: parseFloat(formData.price) || 0,
    views: 0,
    likes: 0,
    isActive: true,
    isAdmin: isAdminEmail(user.email)
};


                    const docRef = await db.collection('listings').add(newListing);
                    console.log('Listing added with ID:', docRef.id);
                    
                    // إرسال إشعار للمستخدم
                    await db.collection('notifications').add({
                        userId: user.uid,
                        message: 'تم نشر إعلانك بنجاح!',
                        type: 'success',
                        timestamp: firebase.firestore.FieldValue.serverTimestamp(),
                        read: false
                    });

                    alert('تم نشر إعلانك بنجاح!');
                } catch (error) {
                    console.error('Error adding listing:', error);
                    alert('فشل نشر الإعلان: ' + error.message);
                    throw error;
                }
            };

            const handleDeleteListing = async (listingId) => {
                if (window.confirm('هل أنت متأكد من حذف هذا الإعلان؟')) {
                    try {
                        await db.collection('listings').doc(listingId).delete();
                        alert('تم حذف الإعلان بنجاح');
                    } catch (error) {
                        alert('حدث خطأ أثناء الحذف: ' + error.message);
                    }
                }
            };

            const handleEditListing = (listing) => {
                // يمكن إضافة منطق التعديل هنا
                alert(`تعديل الإعلان: ${listing.title}`);
            };

            const handleToggleListingStatus = async (listingId, isActive) => {
                try {
                    await db.collection('listings').doc(listingId).update({
                        isActive: isActive,
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                    });
                    alert(`تم ${isActive ? 'تفعيل' : 'حظر'} الإعلان بنجاح`);
                } catch (error) {
                    alert('حدث خطأ أثناء تغيير حالة الإعلان: ' + error.message);
                }
            };

            useEffect(() => {
                let data = listings;
                
                if (activeCat !== 'all') {
                    data = data.filter(i => i.category === activeCat);
                }
                
                if (search) {
                    const searchTerm = search.toLowerCase();
                    data = data.filter(i => 
                        i.title?.toLowerCase().includes(searchTerm) ||
                        i.description?.toLowerCase().includes(searchTerm) ||
                        i.city?.toLowerCase().includes(searchTerm) ||
                        i.category?.toLowerCase().includes(searchTerm)
                    );
                }
                
                setFiltered(data);
            }, [activeCat, search, listings]);

            const handleSendMessage = (listing) => {
                if (!user) {
                    setModals({ auth: true, add: false });
                    alert('يجب تسجيل الدخول لإرسال رسالة');
                    return;
                }
                
                if (user.uid === listing.userId) {
                    alert('لا يمكنك إرسال رسالة إلى نفسك');
                    return;
                }
                
                setShowChat(listing);
            };

            return (
                <div className="min-h-screen relative flex flex-col bg-gray-50 dark:bg-gray-900">
                    <header className="header-compact text-white shadow-lg" role="banner">
                        <div className="container mx-auto px-4 pb-4">
                            <div className="flex justify-between items-center mb-3">
                                <div 
                                    onClick={() => { 
                                        setView('home'); 
                                        setActiveCat('all');
                                        setSearch('');
                                    }} 
                                    className="cursor-pointer touch-feedback" 
                                    role="button" 
                                    aria-label="العودة للصفحة الرئيسية"
                                >
                                    <Logo />
                                </div>
                                
                                <div className="flex items-center gap-2">
                                    <NotificationSystem user={user} />
                                    
                                    <button 
                                        onClick={() => user ? handleSendMessage(filtered[0]) : setModals({...modals, auth: true})} 
                                        className="text-white header-btn rounded-full touch-feedback" 
                                        aria-label="المحادثات"
                                    >
                                        <Icons.Message size={20} />
                                    </button>

                                    <DarkModeToggle />

                                    <button 
                                        onClick={() => user ? setModals({...modals, add: true}) : setModals({...modals, auth: true})} 
                                        className="bg-yellow-400 text-blue-900 header-btn rounded-full touch-feedback" 
                                        aria-label="إضافة إعلان جديد"
                                    >
                                        <Icons.Plus size={20} />
                                    </button>
                                    
                                    <button 
                                        onClick={() => setView(view === 'map' ? 'home' : 'map')} 
                                        className="text-white header-btn rounded-full touch-feedback" 
                                        aria-label={view === 'map' ? 'عرض الشبكة' : 'عرض الخريطة'}
                                    >
                                        {view === 'map' ? <Icons.Grid size={20} /> : <Icons.Map size={20} />}
                                    </button>
                                    
                                    <button 
                                        onClick={() => !user ? setModals({...modals, auth: true}) : setView(view === 'profile' ? 'home' : 'profile')} 
                                        className="bg-white/20 p-2 rounded-full hover:bg-white/30 transition backdrop-blur-sm flex items-center justify-center touch-feedback" 
                                        aria-label="الحساب الشخصي"
                                    >
                                        {user ? (
                                            <img 
                                                src={user.photoURL || 'https://ui-avatars.com/api/?name=' + encodeURIComponent(user.displayName || user.email || 'مستخدم') + '&background=1d4ed8&color=fff'} 
                                                className="w-6 h-6 rounded-full border border-white" 
                                                alt="صورة المستخدم"
                                            />
                                        ) : <Icons.User size={20} />}
                                    </button>
                                </div>
                            </div>
                            
                            <div className="relative">
                                <input 
                                    type="text" 
                                    placeholder="ابحث في الإعلانات..." 
                                    className="w-full bg-white/10 border border-white/20 text-white placeholder-blue-100 py-3 px-10 rounded-xl shadow-sm focus:bg-white focus:text-gray-900 focus:placeholder-gray-400 outline-none transition-all dark:focus:bg-gray-700 dark:focus:text-gray-200" 
                                    value={search} 
                                    onChange={e => setSearch(e.target.value)} 
                                    aria-label="بحث في الإعلانات" 
                                />
                                <div className="absolute right-3 top-3 text-blue-200 pointer-events-none">
                                    <Icons.Search size={20} />
                                </div>
                            </div>
                        </div>
                    </header>

                    {view !== 'profile' && view !== 'map' && (
                        <nav className="bg-white border-b sticky top-[120px] z-30 shadow-sm dark:bg-gray-900" role="navigation" aria-label="أقسام المنتجات">
                            <div className="category-scroll-container hide-scrollbar">
                                {CATEGORIES.map(cat => (
                                    <div 
                                        key={cat.id} 
                                        onClick={() => setActiveCat(cat.id)} 
                                        className={`category-item touch-feedback ${activeCat === cat.id ? 'active-category' : ''}`} 
                                        role="button" 
                                        aria-label={`قسم ${cat.name}`}
                                    >
                                        <div className="category-icon-wrapper" style={activeCat !== cat.id ? { color: cat.color } : {}}>
                                            <cat.icon size={24} />
                                        </div>
                                        <span className="text-[10px] font-bold text-gray-500 whitespace-nowrap dark:text-gray-400">
                                            {cat.name}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        </nav>
                    )}

                    <main className="container mx-auto px-4 py-4 flex-grow" role="main">
                        {view === 'profile' ? (
                            <UserListingsPage 
                                user={user} 
                                onEditAd={(ad) => console.log('Edit ad:', ad)}
                                onDeleteAd={(adId) => console.log('Delete ad:', adId)}
                            />
                        ) : view === 'map' ? (
                            <div className="map-container dark:border-gray-700">
                                <MainMap items={filtered} />
                                <button 
                                    onClick={() => setView('home')} 
                                    className="absolute top-4 left-4 bg-white p-2 rounded-full shadow-lg z-[1000] text-gray-600 touch-feedback dark:bg-gray-800 dark:text-gray-300" 
                                    aria-label="العودة للقائمة الرئيسية"
                                >
                                    <Icons.X size={20}/>
                                </button>
                            </div>
                        ) : (
                            <div>
                                {loading ? (
                                    <div className="text-center py-20 text-gray-400 dark:text-gray-500">
                                        <p>جاري تحميل الإعلانات...</p>
                                    </div>
                                ) : filtered.length === 0 ? (
                                    <div className="text-center py-20 text-gray-400 dark:text-gray-500">
                                        <p className="text-lg mb-2">لا توجد إعلانات حالياً</p>
                                        <p className="text-sm mb-4">كن أول من يضيف إعلاناً!</p>
                                        <button 
                                            onClick={() => user ? setModals({...modals, add: true}) : setModals({...modals, auth: true})}
                                            className="bg-yellow-400 text-blue-900 px-6 py-2 rounded-lg font-bold hover:bg-yellow-500 transition dark:bg-yellow-500"
                                        >
                                            أضف إعلانك الآن
                                        </button>
                                    </div>
                                ) : (
                                    <>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                                            {filtered.map(item => (
                                                <ListingCard 
                                                    key={item.id} 
                                                    item={item} 
                                                    currentUser={user} 
                                                    onMessage={() => handleSendMessage(item)}
                                                    isAdmin={isAdmin}
                                                    onDelete={handleDeleteListing}
                                                    onEdit={handleEditListing}
                                                    onToggleStatus={handleToggleListingStatus}
                                                    onViewDetails={(it) => setSelectedListingId(it.id)}
                                                    onToggleFavorite={toggleFavorite}
                                                    isFavorited={favoritesSet.has(item.id)}
                                                />
                                            ))}
                                        </div>
                                        {isAdmin && <ViewStatistics listings={listings} />}
                                    </>
                                )}
                                {!loading && <Footer listings={listings} />}
                            </div>
                        )}
                    </main>

                    
                    <ListingDetailsModal 
                        item={(selectedListingId ? (listings.find(l => l.id === selectedListingId) || filtered.find(l => l.id === selectedListingId)) : null)} 
                        isOpen={!!selectedListingId} 
                        onClose={() => setSelectedListingId(null)} 
                        isFavorited={!!(selectedListingId && favoritesSet.has(selectedListingId))}
                        onToggleFavorite={toggleFavorite}
                        onRegisterView={registerView}
                    />

{showChat && (
                        <ChatSystem 
                            currentUser={user} 
                            listing={showChat} 
                            onClose={() => setShowChat(null)} 
                        />
                    )}
                    
                    <AuthModal 
                        isOpen={modals.auth} 
                        onClose={() => setModals({...modals, auth: false})} 
                        onLogin={() => {
                            setModals({...modals, auth: false});
                            alert('تم تسجيل الدخول بنجاح!');
                        }} 
                    />
                    
                    <AddListingModal 
                        isOpen={modals.add} 
                        onClose={() => setModals({...modals, add: false})} 
                        user={user} 
                        onAdd={handleAddListing} 
                    />
                    
                    {isAdmin && (
                        <AdminPanel 
                            user={user}
                            listings={listings}
                            onDeleteListing={handleDeleteListing}
                            onEditListing={handleEditListing}
                            onToggleListingStatus={handleToggleListingStatus}
                        />
                    )}
                </div>
            );
        };

export default AppClient;
