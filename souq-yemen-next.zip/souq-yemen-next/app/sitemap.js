import { getAdminDb } from "@/lib/firebaseAdmin";

export default async function sitemap() {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://sooqyemen.com";
  const urls = [
    {
      url: siteUrl,
      lastModified: new Date(),
      changeFrequency: "daily",
      priority: 1.0,
    },
  ];

  try {
    const db = getAdminDb();
    // Try to read a reasonable amount (you can adjust).
    const qs = await db
      .collection("listings")
      .where("isActive", "==", true)
      .limit(500)
      .get();

    for (const doc of qs.docs) {
      urls.push({
        url: `${siteUrl}/ad/${doc.id}`,
        lastModified: new Date(),
        changeFrequency: "weekly",
        priority: 0.7,
      });
    }
  } catch {
    // If admin creds are not configured yet, return at least the home URL.
  }

  return urls;
}
