# Souq Yemen (Next.js + Vercel)

هذا المشروع هو تحويل نسخة `index.html` (React داخل ملف واحد باستخدام Babel Standalone) إلى مشروع **Next.js** حديث جاهز للنشر على **Vercel** مع:
- روابط حقيقية لكل إعلان: `/ad/:id`
- Meta Tags / OpenGraph ديناميكية لكل إعلان (مناسبة للمشاركة والأرشفة)
- `sitemap.xml` ديناميكي

## 1) التشغيل محلياً (اختياري)
> إذا جهازك لا يدعم Node حديث، يمكنك تخطي التشغيل المحلي والذهاب للنشر على Vercel مباشرة.

```bash
npm install
npm run dev
```

## 2) إعداد متغيرات البيئة (مهم)
انسخ `.env.example` إلى `.env.local` في جهازك (أو ضعها في Vercel).

### Public (Firebase Client)
ضع قيم Firebase الخاصة بمشروعك في:
- `NEXT_PUBLIC_FIREBASE_*`

> ملاحظة: في هذا المشروع وضعت قيم fallback مطابقة للقيم الموجودة في ملفك الأصلي. **الأفضل دائماً** أن تجعلها متغيرات بيئة على Vercel.

### Server (Firebase Admin) — ضروري للـ SEO الحقيقي
لجعل `generateMetadata` يعمل (حتى يظهر عنوان/وصف/صورة الإعلان عند مشاركة الرابط)، يجب إعداد Firebase Admin.

في Vercel:
1) Firebase Console → Project Settings → Service Accounts
2) Generate new private key (JSON)
3) ضع محتوى JSON في متغير واحد:
- `FIREBASE_SERVICE_ACCOUNT_JSON`

> تأكد أن قيمة `private_key` تحتوي على `\n` وليس أسطر فعلية.

## 3) النشر على Vercel (الموصى به)
1) ارفع المشروع على GitHub (أو ارفعه مباشرة في Vercel)
2) Vercel → New Project → Import
3) ضع Environment Variables (قسم 2)
4) Deploy

### ربط الدومين
Vercel → Settings → Domains → أضف `sooqyemen.com`
واتبع تعليمات DNS التي يعطيك إياها Vercel.

## 4) أماكن مهمة في الكود
- `app/page.jsx` : الصفحة الرئيسية (تشغل التطبيق الحالي كـ Client Component)
- `app/ad/[id]/page.jsx` : صفحة الإعلان + `generateMetadata` (SEO)
- `app/sitemap.js` : Sitemap ديناميكي
- `lib/firebaseAdmin.js` : اتصال Firebase Admin (للسيرفر)
- `lib/firebaseClient.js` : اتصال Firebase Client (للمتصفح)

## ملاحظة مهمة
- لو لم تضع Firebase Admin env vars، المشروع سيعمل، لكن الـ SEO والمشاركة ستصبح “fallback” ولن تظهر تفاصيل الإعلان في واتساب/فيسبوك بالشكل المطلوب.
